package com.templestay_portal.rest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.templestay_portal.model.ModelReservation;
import com.templestay_portal.service.IServiceReservation;



public class testreservation {
    // SLF4J Logging
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    private static ApplicationContext context = null;
    private static IServiceReservation reservation  = null;
    
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        context = new ClassPathXmlApplicationContext("file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml");
        reservation = context.getBean("servicereservation", IServiceReservation.class);
    }
    
    @Test
    public void testgetReservation() {
        ModelReservation model = new ModelReservation(); 
        model.setUserid("aa");
        ModelReservation result = reservation.getReservation(model);
        assertSame(result.getNumber(), 3);
    }
}
