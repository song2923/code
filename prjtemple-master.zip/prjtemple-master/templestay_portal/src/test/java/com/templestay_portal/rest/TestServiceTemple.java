package com.templestay_portal.rest;


import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.templestay_portal.model.ModelTemple;
import com.templestay_portal.service.IServiceTemple;


public class TestServiceTemple {
    // SLF4J Logging
    //private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    private static ApplicationContext context = null;
    private static IServiceTemple service = null;
    
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {        
        context= new ClassPathXmlApplicationContext("file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml");
        service=context.getBean("servicetemple", IServiceTemple.class);
    }
    
    @Test
    public void testInsertTemple()  {
        ModelTemple model = new ModelTemple();
        model.setTemplecd("귀요미사찰");
        model.setTemplephone("02-123-4567");
        int result = service.insertTempleOne(model);
        assertEquals(result, 1);
    }
    
    @Test
    public void testgetTempleOne() {     
        ModelTemple result = service.getTempleOne(0);
        assertEquals(result.getTemplephone(), "02-123-4567");
    }
    

    @Test
    public void testUpdateTempleProgram() {
        ModelTemple updatemodel = new ModelTemple();
        updatemodel.setTempleaddr_postcode("aaaa");
        updatemodel.setTempleaddr_road("bbb");
        updatemodel.setTempleaddr_jibun("ddd");
        updatemodel.setTemplephone("02-456-7890");

        ModelTemple searchmodel = new ModelTemple();
        searchmodel.setTemplecd("가나다");
      
        int result = service.templeInfoUpdate(updatemodel, searchmodel.getTemplecd());
        assertEquals(result, 1);
    }
    @Test
    public void testDeleteTempleProgram() {
        ModelTemple model = new ModelTemple();
        model.setTemplecd("귀요미사찰");
       
        int result = service.deleteTemple(model);
        assertEquals(result, 1);
    }
    
    @Test
    public void testGetTempleList() {       
        List<ModelTemple> result = service.getTempleList();
        assertEquals(result.size(), 1);
        assertEquals(result.get(0).getTemplecd(), "멋쟁이사찰");
    }
}
