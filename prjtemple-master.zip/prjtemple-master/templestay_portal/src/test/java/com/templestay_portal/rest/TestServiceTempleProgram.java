package com.templestay_portal.rest;


import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.templestay_portal.model.ModelTemple;
import com.templestay_portal.model.ModelTemple_Program;

import com.templestay_portal.service.IServiceTempleProgram;

public class TestServiceTempleProgram {
    // SLF4J Logging
    //private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    private static ApplicationContext context = null;
    private static IServiceTempleProgram service = null;
    
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {        
        context= new ClassPathXmlApplicationContext("file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml");
        service=context.getBean("servicetempleprogram", IServiceTempleProgram.class);
    }
    
    @Test
    public void testInsertTempleprogram()  {
        ModelTemple_Program modelprogram = new ModelTemple_Program();
        modelprogram.setProgramname("programname");
        modelprogram.setProgramprice(10000);
                
        int result = service.insertTempleProgramOne(modelprogram);
        assertEquals(result, 1);
    }
    
    @Test
    public void testgetTempleProgramOne() {     
        ModelTemple_Program result = service.getTempleProgramOne(0);
        assertEquals(result.getProgramdetail(), "하하호호체험");
    }
    

    @Test
    public void testUpdateTempleProgram() {
        ModelTemple_Program updatemodel = new ModelTemple_Program();
        updatemodel.setProgramname("updatename");
        updatemodel.setAvailabledate(new Date());
        updatemodel.setProgramprice(30000);
        updatemodel.setMaxperson(300);
        
        ModelTemple_Program searchmodel = new ModelTemple_Program();
        searchmodel.setProgramname("programname");
      
        int result = service.updateTempleProgram(updatemodel, searchmodel);
        assertEquals(result, 1);
    }
    @Test
    public void testDeleteTempleProgram() {
        ModelTemple_Program model = new ModelTemple_Program();
        model.setProgramno(34);
       
        int result = service.deleteTempleProgram(model);
        assertEquals(result, 1);
    }
    
    @Test
    public void testGetTempleProgramList() {       
        List<ModelTemple_Program> result = service.getTempleProgramList(1,7);
        assertEquals(result.size(), 7);
        assertEquals(result.get(0).getProgramname(), "웃어보자");
        assertEquals(result.get(1).getProgramname(), "영기애교배우기");
        assertEquals(result.get(6).getProgramname(), "웃어보자6");

    }
}
