package com.templestay_portal.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.templestay_portal.dao.IDaoTempleProgram;
import com.templestay_portal.model.ModelTemple;
import com.templestay_portal.model.ModelTemple_Program;

@Service("servicetempleprogram")
public class ServiceTempleProgram implements IServiceTempleProgram {
    // SLF4J Logging
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Autowired
    @Qualifier("daotempleprogram")
    IDaoTempleProgram dao;
    

    
    @Override
    public int insertTempleProgramOne(ModelTemple_Program board) {
        int result = -1;
        try {
             result = dao.insertTempleProgramOne(board);
        } catch (Exception e) {
            logger.error("insertTempleProgramOne" + e.getMessage() );
        }
        return result;
    }
    @Override
    public ModelTemple_Program getTempleProgramOne(Integer programno) {
        ModelTemple_Program result = null;
        try {
             result = dao.getTempleProgramOne(programno);
        } catch (Exception e) {
            logger.error("getTempleProgramOne" + e.getMessage() );
        }
        return result;
        
    }
    

    
    @Override
    public int deleteTempleProgram(ModelTemple_Program board) {
        int result = -1;
        try {
            result = dao.deleteTempleProgram(board);
        } catch (Exception e) {
            logger.error("deleteTempleProgram" + e.getMessage());
        }
        
        return result;
    }

    @Override
    public List<ModelTemple_Program> getTempleProgramList(Integer start,Integer end) {
        List<ModelTemple_Program> result = null;
        try {
            result = dao.getTempleProgramList(start,end);
        } catch (Exception e) {
            logger.error("getTempleProgramList " + e.getMessage() );
        }
        
        return result;
    }
    @Override
    public int getTempleProgramtotal() {
        int result = -1;
    try {
        result = dao.getTempleProgramtotal();
    } catch (Exception e) {
        logger.error("deleteTempleProgram" + e.getMessage());
    }
    
    return result;
    }
    @Override
    public ModelTemple_Program getTempleProgramTop5() {
        ModelTemple_Program result = null;
        try {
             result = dao.getTempleProgramTop5();
        } catch (Exception e) {
            logger.error("getTempleProgramOne" + e.getMessage() );
        }
        return result;
    }
    @Override
    public int templeInfoDelete(ModelTemple_Program model) {
        int result = -1;
        try {
            result = dao.templeInfoDelete(model);
        } catch (Exception e) {
            logger.error("deleteBoard" + e.getMessage());
        }
        
        return result;
    }
    @Override
    public int updateTempleProgram(ModelTemple_Program updatemodel,
            ModelTemple_Program searchmodel) {
        // TODO Auto-generated method stub
        return 0;
    }
    @Override
    public ModelTemple_Program templeInfoUpdate(ModelTemple_Program model) {
        // TODO Auto-generated method stub
        return null;
    }
    @Override
    public int templeProgramInfoUpdate(ModelTemple_Program updatemodel,
            String whereTemplecd) {
        int result=0;
        try {
            result = dao.templeProgramInfoUpdate(updatemodel, whereTemplecd);
        } catch (Exception e) {
            logger.error("updateTemple" + e.getMessage() );
        }
        
        return result;
    }
 


 
 


}
