package com.templestay_portal.service;

import java.util.List;

import com.templestay_portal.model.ModelTemple;
import com.templestay_portal.model.ModelTemple_Program;



public interface IServiceTemple {
   
    ModelTemple getTempleOne(Integer programno);
    int deleteTemple(ModelTemple model);
    List<ModelTemple> getTempleList();
    int insertTempleOne(ModelTemple board);
    int templeInfoUpdate(ModelTemple updatemodel, String whereTemplecd);
}

