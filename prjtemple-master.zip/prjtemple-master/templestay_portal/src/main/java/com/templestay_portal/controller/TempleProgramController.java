package com.templestay_portal.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.templestay_portal.model.ModelTemple;
import com.templestay_portal.model.ModelTemple_Program;
import com.templestay_portal.service.IServiceTempleProgram;
import com.templestay_portal.service.IServiceUser;
import com.templestay_portal.service.ServiceTempleProgram;


/**
 * Handles requests for the application home page.
 */
@Controller
public class TempleProgramController {

    
    @Autowired
    @Qualifier("servicetempleprogram")
    IServiceTempleProgram srv;
   
    
    
	private static final Logger logger = LoggerFactory.getLogger(TempleProgramController.class);
	
	//android에서 보낸 인자를 받아 처리
	
	//리스트를 반환하는 메서드
    @RequestMapping(value = "/templeprogramlist", method =  {RequestMethod.GET, RequestMethod.POST} )
    @ResponseBody
    //리스트를 시작 할 객체를 @RequestParam으로 받음
    public List<ModelTemple_Program> templeprogramcontroller( 
            @RequestParam(value="start") Integer start
                   ) throws Throwable  {

        //리스트의 총 크기를 확인하기 위한 코드 
        int total = srv.getTempleProgramtotal();
        
        //시작값에서 총 크기까지 리스트를 받아 ModelTemple_Program List를 만들어 result로 반환
        List<ModelTemple_Program> result = srv.getTempleProgramList(start,total);
        
        return result;
    }
    //정보창에 보여줄 템플프로그램 정보 리턴
    @RequestMapping(value = "/templeprogramone", method = {RequestMethod.GET, RequestMethod.POST} )
    @ResponseBody
    public ModelTemple_Program getTempleOne(
            @RequestParam("programno") Integer programno) throws Throwable {
        
        ModelTemple_Program result = srv.getTempleProgramOne(programno);
        
        return  result;

    }
    
    //programno에 해당하는 data를 삭제하기 위한 메서드
    @RequestMapping(value = "/templeInfoDelete", method =  {RequestMethod.GET, RequestMethod.POST} )
    @ResponseBody
    public int getTempleInfoDelete(
            @RequestParam(value="programno") Integer programno
                   ) throws Throwable  {
        ModelTemple_Program model = new ModelTemple_Program(programno);
        int result = srv.templeInfoDelete(model);
        
        //처리가 잘 되었는지 result 값 확인
        if( result > 0 ){
            return result;
        }
        else {       
            return result;            
        }
    }
    
    //data 한개를 Insert 하기위한 메서드
    @RequestMapping(value="/insertTempleProgramOne", method={RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public int insertTempleOne( 
            @RequestBody ModelTemple_Program model) {
        
        int result = srv.insertTempleProgramOne(model);
        
        return result;
    }
    
    @RequestMapping(value="/templeProgramInfoUpdate", method={RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public int templeInfoUpdate( 
            @RequestBody Map<String, Object> map
            ) {
        ModelTemple_Program updatemodel = new Gson().fromJson( map.get("updateTemple").toString(), ModelTemple_Program.class);
        String whereTemplecd = (String) map.get("whereTemplecd");
        
        
        int result = srv.templeProgramInfoUpdate(updatemodel, whereTemplecd);
        
        return result;
    }
    

}
