package com.templestay_portal.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.templestay_portal.dao.IDaoBoard_Article;
import com.templestay_portal.model.ModelBoard;
import com.templestay_portal.model.ModelBoard_Article;

@Service("serviceboard_article")
public class ServiceBoard_Article implements IServiceBoard_Article{
    // SLF4J Logging
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Autowired
    @Qualifier("daoboard_article")
    IDaoBoard_Article dao;

    @Override
    public int insertBoard_Article1(ModelBoard_Article board_article) {
        int result = -1;
        try {
            result = dao.insertBoard_Article1(board_article);
        } catch (Exception e) {
            logger.error("insertBoard_Article1 " + e.getMessage() );
        }        
        return result;
    }
    
    @Override
    public int insertBoard_Article2(ModelBoard_Article board_article) {
        int result = -1;
        try {
            result = dao.insertBoard_Article2(board_article);
        } catch (Exception e) {
            logger.error("insertBoard_Article2 " + e.getMessage() );
        }        
        return result;
    }
    
    @Override
    public int getBoard_Article_TotalRecord1() {
        int result = -1;
        try {
            result = dao.getBoard_Article_TotalRecord1();
        } catch (Exception e) {
            logger.error("getBoard_Article_TotalRecord1 " + e.getMessage() );
        }        
        return result;
    }
    
    @Override
    public int getBoard_Article_TotalRecord2() {
        int result = -1;
        try {
            result = dao.getBoard_Article_TotalRecord2();
        } catch (Exception e) {
            logger.error("getBoard_Article_TotalRecord2 " + e.getMessage() );
        }        
        return result;
    }
   

    @Override
    public ModelBoard_Article getBoard_Article(int articleno) {
        ModelBoard_Article result = null;
        try {
            result = dao.getBoard_Article(articleno);
        } catch (Exception e) {
            logger.error("getBoard_Article " + e.getMessage() );
        }        
        return result;
    }
    
    @Override
    public ModelBoard_Article getBoard_Article_Detail1(int position) {
        ModelBoard_Article result = null;
        try {
            result = dao.getBoard_Article_Detail1(position);
        } catch (Exception e) {
            logger.error("getBoard_Article_Detail1 " + e.getMessage() );
        }        
        return result;
    }
    
    @Override
    public ModelBoard_Article getBoard_Article_Detail2(int position) {
        ModelBoard_Article result = null;
        try {
            result = dao.getBoard_Article_Detail2(position);
        } catch (Exception e) {
            logger.error("getBoard_Article_Detail2 " + e.getMessage() );
        }        
        return result;
    }
    

    @Override
    public List<ModelBoard_Article> getBoard_ArticleList1(int start, int end) {
        List<ModelBoard_Article> result = null;
        try {
            result = dao.getBoard_ArticleList1(start, end);
        } catch (Exception e) {
            logger.error("getBoard_ArticleList1 " + e.getMessage() );
        }        
        return result;
    }
    
    @Override
    public List<ModelBoard_Article> getBoard_ArticleList2(int start, int end) {
        List<ModelBoard_Article> result = null;
        try {
            result = dao.getBoard_ArticleList2(start, end);
        } catch (Exception e) {
            logger.error("getBoard_ArticleList2 " + e.getMessage() );
        }        
        return result;
    }
    
    


    @Override
    public int updateBoard_ArticleList(ModelBoard_Article board_article) {
        int result = -1;
        try {
            result = dao.updateBoard_ArticleList(board_article);
        } catch (Exception e) {
            logger.error("updateBoard_ArticleList" + e.getMessage() );
        }        
        return result;
    }

    
    

    @Override
    public int transDeleteArticle(String articleno) {
        int result = -1;
        result = dao.delete_Article_Comment(articleno);
        result = dao.delete_Article(articleno);
        return result;
    }

    @Override
    public int delete_Article(String articleno1) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int delete_Article_Comment(String articleno2) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public ModelBoard_Article getBoard_Article_Articleno1(int position) {
        ModelBoard_Article result = null;
        try {
            result = dao.getBoard_Article_Articleno1(position);
        } catch (Exception e) {
            logger.error("getBoard_Article_Articleno1 " + e.getMessage() );
        }        
        return result; 
    }

    @Override
    public ModelBoard_Article getBoard_Article_Articleno2(int position) {
        ModelBoard_Article result = null;
        try {
            result = dao.getBoard_Article_Articleno2(position);
        } catch (Exception e) {
            logger.error("getBoard_Article_Articleno2 " + e.getMessage() );
        }        
        return result;
    }
   
}
