package com.templestay_portal.model;

import java.util.Date;

import android.graphics.drawable.Drawable;

public class ModelTemple_Program {
    
    private String templecd;
    private Integer programno;
    private Integer programtype;
    private String programname;
    private String programdetail;
    private Integer programprice;
    private Drawable programimage;
    private Integer maxperson;
    private Integer totalperson;
    private Date availabledate;
    private Integer programtotal;
    
    public ModelTemple_Program() {
        super();
    }

    public String getTemplecd() {
        return templecd;
    }
    public void setTemplecd(String templecd) {
        this.templecd = templecd;
    }
    public Integer getProgramno() {
        return programno;
    }
    public void setProgramno(Integer programno) {
        this.programno = programno;
    }
    public Integer getProgramtype() {
        return programtype;
    }
    public void setProgramtype(Integer programtype) {
        this.programtype = programtype;
    }
    public String getProgramname() {
        return programname;
    }
    public void setProgramname(String programname) {
        this.programname = programname;
    }
    public String getProgramdetail() {
        return programdetail;
    }
    public void setProgramdetail(String programdetail) {
        this.programdetail = programdetail;
    }
    public Integer getProgramprice() {
        return programprice;
    }
    public void setProgramprice(Integer programprice) {
        this.programprice = programprice;
    }
    public Drawable getProgramimage() {
        return programimage;
    }
    public void setProgramimage(Drawable programimage) {
        this.programimage = programimage;
    }
    public Integer getMaxperson() {
        return maxperson;
    }
    public void setMaxperson(Integer maxperson) {
        this.maxperson = maxperson;
    }
    public Integer getTotalperson() {
        return totalperson;
    }
    public void setTotalperson(Integer totalperson) {
        this.totalperson = totalperson;
    }
    public Date getAvailabledate() {
        return availabledate;
    }
    public void setAvailabledate(Date availabledate) {
        this.availabledate = availabledate;
    }

    public ModelTemple_Program(Integer programno) {
        super();
        this.programno = programno;
    }

    public Integer getProgramtotal() {
        return programtotal;
    }

    public void setProgramtotal(Integer programtotal) {
        this.programtotal = programtotal;
    }



}
