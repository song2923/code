package com.templestay_portal.dao;

import com.templestay_portal.model.ModelUser;


public interface IDaoUser {

    int idcheck(ModelUser user);
    int insertuser(ModelUser user);
    ModelUser login(ModelUser user);
    int edituser(ModelUser user);
    int outuser(ModelUser user);
}
