package com.templestay_portal.service;

import com.templestay_portal.dao.IDaoReservation;

public interface IServiceReservation extends IDaoReservation{
   

}

