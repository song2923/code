package com.templestay_portal.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.templestay_portal.dao.IDaoBoard_Article;
import com.templestay_portal.model.ModelBoard;
import com.templestay_portal.model.ModelBoard_Article;

public interface IServiceBoard_Article extends IDaoBoard_Article {
        
    int transDeleteArticle(String articleno);
      
}
