package com.templestay_portal.controller;


import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.templestay_portal.model.ModelUser;
import com.templestay_portal.service.IServiceReservation;
import com.templestay_portal.service.IServiceUser;

@Controller
@RequestMapping("/reservation")
public class ReservationController {

    @Autowired
    @Qualifier("servicereservation")
    IServiceReservation srv;

	private static final Logger logger = LoggerFactory.getLogger(ReservationController.class);
	
	@RequestMapping(value = "/reservation_list", method = RequestMethod.GET)
	public String reservation_list(Model model
	        , HttpSession session
	        ) {
		logger.info("reservation_list");

		// get으로  temple의 이름, 번호, 다 + templeprogram 의 날짜 프로그램 이름 등 모두
		
		// model.addAttribute("", );
		
		return "reservation/reservation_list";
	}
	
	   @RequestMapping(value = "/reservation_view", method = RequestMethod.GET)
	    public String reservation_view(Model model
	            , HttpSession session
	            ) {
	        logger.info("reservation_view");

	        return "reservation/reservation_view";
	    }
}
