package com.templestay_portal.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import com.templestay_portal.model.ModelUser;

@Repository("daouser")
public class DaoUser implements IDaoUser {
    
    @Autowired
    @Qualifier("sqlSession")
    SqlSession session;
    
    @Override
    public int idcheck(ModelUser user) {
        return session.selectOne("mapper.mapperuser.idcheck", user);
    }
    
    @Override
    public int insertuser(ModelUser user) {
        return session.insert("mapper.mapperuser.insertuser", user);
    }
    
    @Override
    public ModelUser login(ModelUser user) {
        return session.selectOne("mapper.mapperuser.login", user);
    }
    
    @Override
    public int edituser(ModelUser user) {
        return session.update("mapper.mapperuser.edituser", user);
    }
    
    @Override
    public int outuser(ModelUser user) {
        return session.delete("mapper.mapperuser.outuser", user);
    }
}
