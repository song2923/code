package com.templestay_portal.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.templestay_portal.model.ModelTemple;
import com.templestay_portal.model.ModelTemple_Program;

@Repository("daotempleprogram")
public class DaoTempleProgram implements IDaoTempleProgram {
    // SLF4J Logging
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Autowired
    @Qualifier("sqlSession")
    SqlSession session;



    @Override
    public int insertTempleProgramOne(ModelTemple_Program model) {
        return session.insert("mapper.mappertempleprogram.insertTempleProgramOne",model);
    }


    @Override
    public ModelTemple_Program getTempleProgramOne(Integer programno) {
        return session.selectOne("mapper.mappertempleprogram.getTempleProgramOne", programno);
    }

    @Override
    public int updateTempleProgram(ModelTemple_Program updatemodel,
            ModelTemple_Program searchmodel) {
        Map<String, ModelTemple_Program> map = new HashMap<String, ModelTemple_Program>();
        map.put("updateValue", updatemodel);
        map.put("searchValue", searchmodel);
        return session.update("mapper.mappertempleprogram.updateTempleProgram", map);
    }

    @Override
    public int deleteTempleProgram(ModelTemple_Program temple) {
        return session.delete("mapper.mappertempleprogram.deleteTempleProgram", temple);
    }

    @Override
    public List<ModelTemple_Program> getTempleProgramList(Integer start,Integer end) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("startValue", start);
        map.put("endhValue", end);
        return session.selectList("mapper.mappertempleprogram.getTempleProgramList",map);
    }


    @Override
    public int getTempleProgramtotal() {
        return session.selectOne("mapper.mappertempleprogram.getTempleProgramTotal");
    }


    @Override
    public ModelTemple_Program getTempleProgramTop5() {
        return session.selectOne("mapper.mappertempleprogram.getTempleProgramTop5");
    }


    @Override
    public int templeInfoDelete(ModelTemple_Program model) {
        return session.delete("mapper.mappertempleprogram.templeInfoDelete", model);
    }


    @Override
    public int templeProgramInfoUpdate(ModelTemple_Program updatemodel,
            String whereTemplecd) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("updateprogram", updatemodel.getProgramname());
        map.put("updatertype", updatemodel.getProgramtype());
        map.put("updaterdetail", updatemodel.getProgramdetail());
        map.put("updatepricd", updatemodel.getProgramprice());
        map.put("updatemaxperson", updatemodel.getMaxperson());
        map.put("searchValue", whereTemplecd);
        return session.update("mapper.mappertempleprogram.updateTempleProgram", map);
    }
}
