package com.templestay_portal.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.templestay_portal.model.ModelBoard;
import com.templestay_portal.model.ModelBoard_Article;

@Repository("daoboard_article")
public class DaoBoard_Article implements IDaoBoard_Article{
    // SLF4J Logging
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Autowired
    @Qualifier("sqlSession")
    SqlSession session;

    @Override
    public int insertBoard_Article1(ModelBoard_Article board_article) {
        return session.insert("mapper.mapperBoard.insertBoard_Article1", board_article);
    }
    
    @Override
    public int insertBoard_Article2(ModelBoard_Article board_article) {
        return session.insert("mapper.mapperBoard.insertBoard_Article2", board_article);
    }
    
    @Override
    public int getBoard_Article_TotalRecord1() {
        return session.selectOne("mapper.mapperBoard.getBoard_Article_TotalRecord1");
    }
    
    @Override
    public int getBoard_Article_TotalRecord2() {
        return session.selectOne("mapper.mapperBoard.getBoard_Article_TotalRecord2");
    }
  
    @Override
    public ModelBoard_Article getBoard_Article(int articleno) {
        return session.selectOne("mapper.mapperBoard.getBoardOne", articleno);
    }
    
    @Override
    public ModelBoard_Article getBoard_Article_Detail1(int position) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("position", position);
        return session.selectOne("mapper.mapperBoard.getBoard_Article_Detail1", map);
    }
    
    @Override
    public ModelBoard_Article getBoard_Article_Detail2(int position) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("position", position);
        return session.selectOne("mapper.mapperBoard.getBoard_Article_Detail2", map);
    }

    @Override
    public List<ModelBoard_Article> getBoard_ArticleList1(int start, int end) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("start", start);
        map.put("end", end);
        return session.selectList("mapper.mapperBoard.getBoard_ArticleList1", map);
    }
    
    @Override
    public List<ModelBoard_Article> getBoard_ArticleList2(int start, int end) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("start", start);
        map.put("end", end);
        return session.selectList("mapper.mapperBoard.getBoard_ArticleList2", map);
    }
    

    @Override
    public int updateBoard_ArticleList(ModelBoard_Article board_article) {
        return session.update("mapper.mapperBoard.updateBoard_ArticleList", board_article);  
    }

    @Override
    public int delete_Article(String articleno) {
        return session.delete("mapper.mapperBoard.delete_Article", articleno);
    }

    @Override
    public int delete_Article_Comment(String articleno) {
        return session.delete("mapper.mapperBoard.delete_Article_Comment", articleno);
    }

    @Override
    public ModelBoard_Article getBoard_Article_Articleno1(int position) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("position", position);
        return session.selectOne("mapper.mapperBoard.getBoard_Article_Articleno1", map);
    }

    @Override
    public ModelBoard_Article getBoard_Article_Articleno2(int position) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("position", position);
        return session.selectOne("mapper.mapperBoard.getBoard_Article_Articleno2", map);
    }

   

    
}
