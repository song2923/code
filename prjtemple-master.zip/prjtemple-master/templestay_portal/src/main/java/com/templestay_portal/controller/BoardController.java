package com.templestay_portal.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.templestay_portal.model.ModelBoard;
import com.templestay_portal.model.ModelBoard_Article;
import com.templestay_portal.model.ModelBoard_Article_Comment;
import com.templestay_portal.model.ModelTemple;
import com.templestay_portal.model.ModelUser;
import com.templestay_portal.service.IServiceBoard;
import com.templestay_portal.service.IServiceBoard_Article;
import com.templestay_portal.service.IServiceBoard_Article_Comment;


/**
 * Handles requests for the application home page.
 */
@Controller
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Autowired
	@Qualifier("serviceboard_article")
	IServiceBoard_Article svr_article;
	@Autowired
	@Qualifier("serviceboard")
    IServiceBoard svr_board;
	@Autowired
	@Qualifier("serviceboard_article_comment")
    IServiceBoard_Article_Comment svr_article_comment;
	
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	@RequestMapping(value = "/board/insertBoard_Article1", method = {RequestMethod.GET, RequestMethod.POST})
    public int insertBoard_Article1(Model model
            ,@RequestParam (value="userid",defaultValue="")String userid
            ,@RequestParam (value="title",defaultValue="")String title
            ,@RequestParam (value="content",defaultValue="")String content) {
        logger.info("/board/insertBoard_Article1");
        
        ModelBoard_Article board_article = new ModelBoard_Article();
        board_article.setUserid(userid);
        board_article.setTitle(title);
        board_article.setContent(content);
        
        int result = svr_article.insertBoard_Article1(board_article);
    
        return result;
    }
	
	@RequestMapping(value = "/board/insertBoard_Article2", method = {RequestMethod.GET, RequestMethod.POST})
    public int insertBoard_Article2(Model model
            ,@RequestParam (value="userid",defaultValue="")String userid
            ,@RequestParam (value="title",defaultValue="")String title
            ,@RequestParam (value="content",defaultValue="")String content) {
        logger.info("/board/insertBoard_Article2");
        
        ModelBoard_Article board_article = new ModelBoard_Article();
        board_article.setUserid(userid);
        board_article.setTitle(title);
        board_article.setContent(content);
        
        int result = svr_article.insertBoard_Article2(board_article);
    
        return result;
    }
	
	@RequestMapping(value = "/board/getBoard_ArticleList1", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public List<ModelBoard_Article> getBoard_ArticleList1(Model model
            , @RequestParam(value="start") int start
	        ) throws Throwable  {
        logger.info("/board/getBoard_ArticleList1");        
        
        int total = svr_article.getBoard_Article_TotalRecord1();

        List<ModelBoard_Article> result = svr_article.getBoard_ArticleList1(start, total);
        
        return result;
	
	}
	
	@RequestMapping(value = "/board/getBoard_ArticleList2", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public List<ModelBoard_Article> getBoard_ArticleList2(Model model
            , @RequestParam(value="start") int start
            ) throws Throwable  {
        logger.info("/board/getBoard_ArticleList2");        
        
        int total = svr_article.getBoard_Article_TotalRecord2();

        List<ModelBoard_Article> result = svr_article.getBoard_ArticleList2(start, total);
        
        return result;
    
    }
	
	@RequestMapping(value = "/board/getBoard_Article_Detail1", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public ModelBoard_Article getBoard_Article_Detail1(Model model
            , @RequestParam(value="position") int position){
        logger.info("/board/getBoard_Article_Detail1");        
        
        ModelBoard_Article result = svr_article.getBoard_Article_Detail1(position);
        
        return result;
    
    }
	
	@RequestMapping(value = "/board/getBoard_Article_Detail2", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public ModelBoard_Article getBoard_Article_Detail2(Model model
            , @RequestParam(value="position") int position){
        logger.info("/board/getBoard_Article_Detail2");        
        
        ModelBoard_Article result = svr_article.getBoard_Article_Detail2(position);
        
        return result;
    
    }
	
	@RequestMapping(value = "/board/transDeleteArticle", method = {RequestMethod.GET, RequestMethod.POST})
    public int transDeleteArticle(
            @RequestParam (value="articleno")String articleno)
            {
        logger.info("/board/transDeleteArticle");
        
        ModelBoard_Article_Comment board_article_comment = new ModelBoard_Article_Comment();
        board_article_comment.setArticleno(articleno);
        
        ModelBoard_Article board_article = new ModelBoard_Article();
        board_article.setArticleno(articleno);
        
        int result = svr_article.transDeleteArticle(articleno);
       
    
        return result;
    }

	@RequestMapping(value = "/board/updateBoard_ArticleList", method = {RequestMethod.GET, RequestMethod.POST})
    public int updateBoard_ArticleList(Model model
            , @RequestParam(value="content") String content
            , @RequestParam(value="articleno") String articleno){
        logger.info("/board/updateBoard_ArticleList");        
        
        ModelBoard_Article board_article = new ModelBoard_Article();
        board_article.setContent(content);
        board_article.setArticleno(articleno);
        
        int result = svr_article.updateBoard_ArticleList(board_article);
        
        return result;
    
    }
	
	
	
	
	
	
	
	@RequestMapping(value = "/board/insertBoard_Article_Comment", method = {RequestMethod.GET, RequestMethod.POST})
    public int insertBoard_Article_Comment(Model model
            ,@RequestParam (value="articleno")String articleno
            ,@RequestParam (value="userid")String userid
            ,@RequestParam (value="commentmemo")String commentmemo) {
        logger.info("/board/insertBoard_Article_Comment");
        
        ModelBoard_Article_Comment board_article_comment = new ModelBoard_Article_Comment();
        board_article_comment.setArticleno(articleno);
        board_article_comment.setUserid(userid);
        board_article_comment.setCommentmemo(commentmemo);
        
        int result = svr_article_comment.insertBoard_Article_Comment(board_article_comment);
    
        return result;
    }
	
	@RequestMapping(value = "/board/getBoard_Article_CommentList", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public List<ModelBoard_Article_Comment> getBoard_Article_CommentList(Model model
            , @RequestParam(value="articleno") String articleno
            , @RequestParam(value="start") String start
            ) throws Throwable  {
        logger.info("/board/getBoard_Article_CommentList");        
        
        String total = svr_article_comment.getBoard_Article_Comment_TotalRecord();

        List<ModelBoard_Article_Comment> result = svr_article_comment.getBoard_Article_CommentList(articleno, start, total);
        
        return result;
    
    }
    
    @RequestMapping(value = "/board/getBoard_Article_Articleno1", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public ModelBoard_Article getBoard_Article_Articleno1(Model model
            , @RequestParam(value="position") int position){
        logger.info("/board/getBoard_Article_Articleno1");        
        
        ModelBoard_Article result = svr_article.getBoard_Article_Articleno1(position);
        
        return result;
    
    }
    
    @RequestMapping(value = "/board/getBoard_Article_Articleno2", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public ModelBoard_Article getBoard_Article_Articleno2(Model model
            , @RequestParam(value="position") int position){
        logger.info("/board/getBoard_Article_Articleno2");        
        
        ModelBoard_Article result = svr_article.getBoard_Article_Articleno2(position);
        
        return result;
    
    }
    
    
    
    
    
    
    
}
