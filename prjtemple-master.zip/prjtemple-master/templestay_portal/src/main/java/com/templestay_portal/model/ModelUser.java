package com.templestay_portal.model;


public class ModelUser {
    
    private Integer userno;
    private String userid;
    private String username;
    private String userpassword;
    private String useremail;
    private String userphone;
    
    public ModelUser() {
        super();
    }
    public ModelUser(Integer userno, String userid, String username,
            String userpassword, String useremail, String userphone) {
        super();
        this.userno = userno;
        this.userid = userid;
        this.username = username;
        this.userpassword = userpassword;
        this.useremail = useremail;
        this.userphone = userphone;
    }
    public Integer getUserno() {
        return userno;
    }
    public void setUserno(Integer userno) {
        this.userno = userno;
    }
    public String getUserid() {
        return userid;
    }
    public void setUserid(String userid) {
        this.userid = userid;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getUserpassword() {
        return userpassword;
    }
    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }
    public String getUseremail() {
        return useremail;
    }
    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }
    public String getUserphone() {
        return userphone;
    }
    public void setUserphone(String userphone) {
        this.userphone = userphone;
    }

    @Override
    public String toString() {
        return "ModelUser [userno=" + userno + ", userid=" + userid
                + ", username=" + username + ", userpassword=" + userpassword
                + ", useremail=" + useremail + ", userphone=" + userphone + "]";
    }
    
    public ModelUser(String userid) {
        super();
        this.userid = userid;
    }
    
    public ModelUser(String userid, String userpassword) {
        super();
        this.userid = userid;
        this.userpassword = userpassword;
    }
    
    public ModelUser(String userid, String userpassword, String username,
            String userphone, String useremail) {
        super();
        this.userid = userid;
        this.userpassword = userpassword;
        this.username = username;
        this.userphone = userphone;
        this.useremail = useremail;
    }
}
