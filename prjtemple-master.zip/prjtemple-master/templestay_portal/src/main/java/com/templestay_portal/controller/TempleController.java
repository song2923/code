package com.templestay_portal.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.templestay_portal.model.ModelTemple;
import com.templestay_portal.model.ModelTemple_Program;
import com.templestay_portal.service.IServiceTemple;
import com.templestay_portal.service.IServiceTempleProgram;


/**
 * Handles requests for the application home page.
 */
@Controller
public class TempleController {

    
    @Autowired
    @Qualifier("servicetemple")
    IServiceTemple srv;
    
	private static final Logger logger = LoggerFactory.getLogger(TempleController.class);
   
	
    @RequestMapping(value = "/getTempleOne", method = {RequestMethod.GET, RequestMethod.POST} )
    @ResponseBody
    public ModelTemple getTempleOne(
            @RequestParam("programno") Integer programno) throws Throwable {
        
        ModelTemple result = srv.getTempleOne(programno);
        
        return  result;

    }
    @RequestMapping(value="/templeInfoUpdate", method={RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public int templeInfoUpdate( 
            @RequestBody Map<String, Object> map
            ) {
        ModelTemple updatemodel = new Gson().fromJson( map.get("updateTemple").toString(), ModelTemple.class);
        String whereTemplecd = (String) map.get("whereTemplecd");
        
        
        int result = srv.templeInfoUpdate(updatemodel, whereTemplecd);
        
        return result;
    }
    
                                
    @RequestMapping(value="/insertTempleOne", method={RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public int insertTempleOne( 
            @RequestBody ModelTemple model) {
        
        int result = srv.insertTempleOne(model);
        
        return result;
    }
}
