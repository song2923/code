﻿
-- templestay_portal 데이터베이스 구조 내보내기
DROP DATABASE IF EXISTS templestay_portal;


CREATE DATABASE templestay_portal DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;


-- 사용자 추가
GRANT ALL ON templestay_portal.* TO 'temple1'@'%' IDENTIFIED BY '1234';


FLUSH PRIVILEGES;



-- 데이터베이스 변경
USE templestay_portal;
                

DROP TABLE IF EXISTS TB_Board_Article_Comment;        -- 손자테이블
DROP TABLE IF EXISTS TB_Board_Article_Attachfile;		-- 손자테이블
DROP TABLE IF EXISTS TB_Board_Article;						-- 자식테이블
DROP TABLE IF EXISTS TB_Board;                        -- 부모테이블



DROP TABLE IF EXISTS TB_Reservation;                  -- 자식테이블  

DROP TABLE IF EXISTS TB_Temple_Program;                -- 자식테이블
DROP TABLE IF EXISTS TB_Temple;                        -- 부모테이블
 
DROP TABLE IF EXISTS TB_User;





-- 게시판 종류 테이블
CREATE TABLE IF NOT EXISTS  TB_Board (
      boardcd       NVARCHAR(20)   NOT NULL
    , boardname     NVARCHAR(40)   NOT NULL
    
    , PRIMARY KEY(boardcd)
)
ENGINE=InnoDB 
AUTO_INCREMENT=1 
DEFAULT CHARACTER SET utf8 
COLLATE utf8_general_ci;

insert into TB_Board(boardcd, boardname) values ('free','자유게시판');
insert into TB_Board(boardcd, boardname) values ('notice','공지사항');
insert into TB_Board(boardcd, boardname) values ('qna','질문응답'   );

select * from TB_Board;


-- 회원관리  테이블
DROP TABLE IF EXISTS TB_User;
CREATE TABLE TB_User (
      userno        INT UNSIGNED   NOT NULL AUTO_INCREMENT
    , userid        VARCHAR(50)    NOT NULL
    , username      NVARCHAR(30) 
    , userpassword  NVARCHAR(30) 
    , useremail     NVARCHAR(100)  
    , userphone    NVARCHAR(100)  
       
    , PRIMARY KEY(userid)
    , UNIQUE KEY(userno)
)
ENGINE=InnoDB 
AUTO_INCREMENT=1 
DEFAULT CHARACTER SET utf8 
COLLATE utf8_general_ci;

insert into TB_User( userid, username, userpassword, useremail, userphone ) values ( '01', 'user1', 'passwd01', 'email01', '010'); 
insert into TB_User( userid, username, userpassword, useremail, userphone ) values ( '02', 'user2', 'passwd02', 'email01', '010'); 
insert into TB_User( userid, username, userpassword, useremail, userphone ) values ( '03', 'user3', 'passwd01', 'email01', '010'); 



select * from TB_User;


-- 게시글 테이블
CREATE TABLE IF NOT EXISTS  TB_Board_Article (
      articleno     INT UNSIGNED  NOT NULL AUTO_INCREMENT
    , userid        VARCHAR( 50)  
    , boardcd       NVARCHAR(20)
    , title         NVARCHAR(200) NOT NULL
    , content       MEDIUMTEXT  
    , hit           INT UNSIGNED  DEFAULT  0   
    , nowdate       DateTime
                         
    , PRIMARY KEY(articleno)
    
    , constraint board_article_fk foreign key(boardcd) references TB_Board(boardcd) 
    , constraint user_article_fk foreign key(userid) references TB_User(userid)
)
ENGINE=InnoDB 
AUTO_INCREMENT=1 
DEFAULT CHARACTER SET utf8 
COLLATE utf8_general_ci;

                                                                                                                                                        
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  01', 'article test  01', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  02', 'article test  02', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  03', 'article test  03', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  04', 'article test  04', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  05', 'article test  05', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  06', 'article test  06', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  07', 'article test  07', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  08', 'article test  08', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  09', 'article test  09', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '01', 'free', 'article test  10', 'article test  10', 0, now() );
                                                                                                                                                        
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  01', 'article test  01', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  02', 'article test  02', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  03', 'article test  03', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  04', 'article test  04', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  05', 'article test  05', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  06', 'article test  06', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  07', 'article test  07', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  08', 'article test  08', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  09', 'article test  09', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '02', 'free', 'article test  10', 'article test  10', 0, now() );
                                                                                                                                                        
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  01', 'article test  01', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  02', 'article test  02', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  03', 'article test  03', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  04', 'article test  04', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  05', 'article test  05', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  06', 'article test  06', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  07', 'article test  07', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  08', 'article test  08', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  09', 'article test  09', 0, now() );
insert into TB_Board_Article( userid, boardcd, title, content, hit, nowdate ) values ( '03', 'free', 'article test  10', 'article test  10', 0, now() );


                                                                                                                                                        
select * from TB_Board_Article;

 
-- 댓글 테이블
DROP TABLE IF EXISTS TB_Board_Article_Comment;
CREATE TABLE IF NOT EXISTS  TB_Board_Article_Comment (
      commentno     INT UNSIGNED     NOT NULL AUTO_INCREMENT
    , articleno     INT UNSIGNED          
    , commentmemo   NVARCHAR(4000)
    , nowdate       DateTime 
    , userid        VARCHAR(50)    NOT NULL
                       
    , PRIMARY KEY(commentno)
    , constraint article_comment_fk foreign key(articleno) references TB_Board_Article(articleno)
    , constraint user_comment_fk foreign key(userid) references TB_User(userid)
)
ENGINE=InnoDB 
AUTO_INCREMENT=1 
DEFAULT CHARACTER SET utf8 
COLLATE utf8_general_ci;

insert into TB_Board_Article_Comment( commentmemo, nowdate, userid ) values ( "comment test", now(), '01' );
      
select * from TB_Board_Article_Comment;     
           
           
-- 첨부파일 테이블
DROP TABLE IF EXISTS TB_Board_Article_Attachfile;
CREATE TABLE IF NOT EXISTS  TB_Board_Article_Attachfile (
      attachfileno   INT UNSIGNED    NOT NULL AUTO_INCREMENT
    , articleno      INT UNSIGNED      
    , filename       NVARCHAR(50)    
    , filetype       NVARCHAR(30)    
    , filesize       INT    
	 , tempfilename   NVARCHAR(50)          
                                                  
    , PRIMARY KEY(attachfileno)
    , constraint article_attachfile_fk foreign key(articleno) references TB_Board_Article(articleno)
)
ENGINE=InnoDB 
AUTO_INCREMENT=1 
DEFAULT CHARACTER SET utf8 
COLLATE utf8_general_ci;

Insert into TB_Board_Article_Attachfile (filename, filetype, filesize, tempfilename) values ('어태치파일','파일타입',10, 'tempfilename');
Insert into TB_Board_Article_Attachfile (filename, filetype, filesize, tempfilename) values ('어태치파일','파일타입',10, 'tempfilename');
Insert into TB_Board_Article_Attachfile (filename, filetype, filesize, tempfilename) values ('어태치파일','파일타입',10, 'tempfilename');
Insert into TB_Board_Article_Attachfile (filename, filetype, filesize, tempfilename) values ('어태치파일','파일타입',10, 'tempfilename');
Insert into TB_Board_Article_Attachfile (filename, filetype, filesize, tempfilename) values ('어태치파일','파일타입',10, 'tempfilename');
Insert into TB_Board_Article_Attachfile (filename, filetype, filesize, tempfilename) values ('어태치파일','파일타입',10, 'tempfilename');
Insert into TB_Board_Article_Attachfile (filename, filetype, filesize, tempfilename) values ('어태치파일','파일타입',10, 'tempfilename');

select * from TB_Board_Article_Attachfile;   

           
         
                  
 

--  템플스테이 관리 테이블
DROP TABLE IF EXISTS TB_Temple;
CREATE TABLE IF NOT EXISTS  TB_Temple (
	   templecd             NVARCHAR(30) 
    , templeaddr_postcode  NVARCHAR(50) 
    , templeaddr_road      NVARCHAR(50) 
    , templeaddr_jibun     NVARCHAR(50) 
    , templephone          NVARCHAR(50) 
    
    , PRIMARY KEY(templecd)
)
ENGINE=InnoDB 
AUTO_INCREMENT=1 
DEFAULT CHARACTER SET utf8 
COLLATE utf8_general_ci;

select * from TB_Temple;

--  템플스테이 프로그램 정보  테이블
DROP TABLE IF EXISTS TB_Temple_Program;
CREATE TABLE IF NOT EXISTS  TB_Temple_Program (
	   programno       INT UNSIGNED NOT NULL AUTO_INCREMENT 
    , templecd        NVARCHAR(30)     
    , programtype     INT
    , programname     NVARCHAR(30) 
    , programdetail   NVARCHAR(50) 
    , programprice    INT
    , programimage    NVARCHAR(50) 
    , maxperson       INT
    , totalperson     INT
    , availabledate   Date
    
    , PRIMARY KEY(programno)
    , constraint temple_program_fk foreign key(templecd) references TB_Temple(templecd)   
)
ENGINE=InnoDB 
AUTO_INCREMENT=1 
DEFAULT CHARACTER SET utf8 
COLLATE utf8_general_ci;

select * from TB_Temple_Program; 



--  예약 테이블
CREATE TABLE `tb_reservation` (
	`reservationno` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`programno` INT(10) UNSIGNED NOT NULL,
	`userid` VARCHAR(50) NOT NULL,
	`checkdate` DATETIME NULL DEFAULT NULL,
	`number` INT(11) NULL DEFAULT NULL,
	
	PRIMARY KEY (`reservationno`),
	INDEX `FK_tb_reservation_tb_user` (`userid`),
	INDEX `FK_tb_reservation_tb_temple_program` (`programno`),
	CONSTRAINT `FK_tb_reservation_tb_temple_program` FOREIGN KEY (`programno`) REFERENCES `tb_temple_program` (`programno`) ON UPDATE NO ACTION ON DELETE NO ACTION,
	CONSTRAINT `FK_tb_reservation_tb_user` FOREIGN KEY (`userid`) REFERENCES `tb_user` (`userid`) ON UPDATE NO ACTION ON DELETE NO ACTION
)
ENGINE=InnoDB 
AUTO_INCREMENT=1 
DEFAULT CHARACTER SET utf8 
COLLATE utf8_general_ci;

select * from TB_Reservation; 

  



commit;
  








