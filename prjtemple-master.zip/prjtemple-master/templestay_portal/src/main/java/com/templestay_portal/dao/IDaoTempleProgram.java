package com.templestay_portal.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.templestay_portal.model.ModelTemple;
import com.templestay_portal.model.ModelTemple_Program;

public interface IDaoTempleProgram {
    
    int updateTempleProgram(ModelTemple_Program updatemodel, ModelTemple_Program searchmodel);
    int deleteTempleProgram(ModelTemple_Program board);
    int insertTempleProgramOne(ModelTemple_Program board);
    int getTempleProgramtotal();
    List<ModelTemple_Program> getTempleProgramList(Integer start, Integer end);
    ModelTemple_Program getTempleProgramOne(Integer programno);
    ModelTemple_Program getTempleProgramTop5();
    int templeInfoDelete(ModelTemple_Program model);
    int templeProgramInfoUpdate(ModelTemple_Program updatemodel, String whereTemplecd);

}
