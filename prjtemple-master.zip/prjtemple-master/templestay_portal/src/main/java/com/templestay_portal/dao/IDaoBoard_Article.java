package com.templestay_portal.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.templestay_portal.model.ModelBoard;
import com.templestay_portal.model.ModelBoard_Article;

public interface IDaoBoard_Article {
    
    int insertBoard_Article1( ModelBoard_Article board_article );
    int insertBoard_Article2( ModelBoard_Article board_article );
    
    int getBoard_Article_TotalRecord1();
    int getBoard_Article_TotalRecord2();
    
    ModelBoard_Article getBoard_Article(int articleno);
    
    ModelBoard_Article getBoard_Article_Detail1(int position);
    ModelBoard_Article getBoard_Article_Detail2(int position);
    
    List<ModelBoard_Article> getBoard_ArticleList1(int start, int end);
    List<ModelBoard_Article> getBoard_ArticleList2(int start, int end);
   
    int updateBoard_ArticleList(ModelBoard_Article board_article);   
    
    int delete_Article(String articleno);
    int delete_Article_Comment(String articleno);
    
    
    ModelBoard_Article getBoard_Article_Articleno1(int position);
    ModelBoard_Article getBoard_Article_Articleno2(int position);

    
}
