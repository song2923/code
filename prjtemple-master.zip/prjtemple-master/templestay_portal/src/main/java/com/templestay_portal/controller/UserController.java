package com.templestay_portal.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.templestay_portal.model.ModelUser;
import com.templestay_portal.service.IServiceUser;

@Controller
public class UserController {
    
    private static final Logger logger = LoggerFactory
            .getLogger(UserController.class);
    
    @Autowired
    @Qualifier("serviceuser")
    IServiceUser svr;
    
    @RequestMapping(value = "/register/idcheckrest", method = { RequestMethod.GET, RequestMethod.POST })
    @ResponseBody
    public int insertuser(Model model,
            @RequestParam(value = "userid",     defaultValue = "") String userid) {
        logger.info("/register/idcheckrest");
        ModelUser user = new ModelUser(userid);
        int result = svr.idcheck(user);
        
        return result;
    }
    
    @RequestMapping(value = "/register/insertuserrest", method = { RequestMethod.GET, RequestMethod.POST })
    @ResponseBody
    public int insertuser(Model model,
            @RequestParam(value = "userid",     defaultValue = "") String userid,
            @RequestParam(value = "userpassword", defaultValue = "") String userpassword,
            @RequestParam(value = "username",   defaultValue = "") String username,
            @RequestParam(value = "userphone",  defaultValue = "") String userphone,
            @RequestParam(value = "useremail",  defaultValue = "") String useremail) {
        logger.info("/register/insertuserrest");
        ModelUser user = new ModelUser(userid, userpassword, username, userphone,
                useremail);
        int result = svr.insertuser(user);
        
        return result;
    }
    
    @RequestMapping(value = "/register/loginrest", method = {RequestMethod.GET, RequestMethod.POST} )
    @ResponseBody
    public ModelUser login(Model model
            , @RequestParam(value="userid", defaultValue="") String userid
            , @RequestParam(value="userpassword", defaultValue="") String userpassword  ) {
        logger.info("/register/loginrest");

        ModelUser user = new ModelUser(userid,userpassword);
        user.setUserid(userid);
        user.setUserpassword(userpassword);
        
        ModelUser result = svr.login(user);
        
        return result;
    }
    
    @RequestMapping(value = "/register/edituserrest", method = { RequestMethod.GET, RequestMethod.POST })
    @ResponseBody
    public int edituser(Model model,
            @RequestParam(value = "userid", defaultValue = "") String userid,
            @RequestParam(value = "userpassword", defaultValue = "") String userpassword,
            @RequestParam(value = "username",   defaultValue = "") String username,
            @RequestParam(value = "userphone",  defaultValue = "") String userphone,
            @RequestParam(value = "useremail",  defaultValue = "") String useremail) {
        logger.info("/register/edituserrest");
        ModelUser user = new ModelUser(userid,userpassword, username, userphone,useremail);
        int result = svr.edituser(user);
        
        return result;
    }
    
    @RequestMapping(value = "/register/outuserrest", method = { RequestMethod.GET, RequestMethod.POST })
    @ResponseBody
    public int outuser(Model model,
            @RequestParam(value = "userid", defaultValue = "") String userid){
        logger.info("/register/outuserrest");
        ModelUser user = new ModelUser(userid);
        int result = svr.outuser(user);
        
        return result;
    }
    
}
