package com.example.administrator.board;

import android.support.test.runner.AndroidJUnit4;

import com.example.administrator.board.http.HttpBoard;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class TestHttpBoard {

    /**
     * android ---전송(값2개)---> spring ---반환(json:JSONArray)--->andorid
     * 1. 안드로이드 ---> 스프링     : 안드로이드는 값을 1개 스프링 서버로 전송한다.
     * 2. 스프링     ---> 안드로이드 : 안드로이드는 Json(JSONObject)을 스프링으로부터 반환 받는다.
     */


    @Test
    public void test02(){
        //String result = new HttpBoard().insertBoard_Article("aaa", "test", "test");
       // assertEquals(1, result);
    }
}
