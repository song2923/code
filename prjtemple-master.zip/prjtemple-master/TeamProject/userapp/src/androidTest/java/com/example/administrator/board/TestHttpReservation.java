package com.example.administrator.board;

import android.support.test.runner.AndroidJUnit4;

import com.example.administrator.board.http.HttpTemple;
import com.example.administrator.board.model.ModelTemple;
import com.google.gson.Gson;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class TestHttpReservation {

    /**
     * android ---전송(값1개)---> spring ---반환(json:JSONObject)--->andorid
     * 1. 안드로이드 ---> 스프링     : 안드로이드는 값을 1개 스프링 서버로 전송한다.
     * 2. 스프링     ---> 안드로이드 : 안드로이드는 Json(JSONObject)을 스프링으로부터 반환 받는다.
     */
    @Test
    public void test_gson(){
        ModelTemple modela = new ModelTemple();
        modela.setTemplecd("aaaaaa");
        modela.setTemplephone("010-12341-34523");
        modela.setTempleaddr_postcode("adafdsa");
        modela.setTempleaddr_road("asdfad");
        modela.setTempleaddr_jibun("adgad");

        Map<String, ModelTemple> map = new HashMap<>();
        map.put("modela", modela);
        //map.put("string", str);

        try {
            String data = new Gson().toJson(map);

            assertEquals(data,"");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
