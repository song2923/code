package com.example.administrator.board;

import android.support.test.runner.AndroidJUnit4;

import com.example.administrator.board.http.HttpLogin;
import com.example.administrator.board.model.ModelUser;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class TestHttpLogin {

    /**
     * android ---전송(값1개)---> spring ---반환(json:JSONObject)--->andorid
     * 1. 안드로이드 ---> 스프링     : 안드로이드는 값을 1개 스프링 서버로 전송한다.
     * 2. 스프링     ---> 안드로이드 : 안드로이드는 Json(JSONObject)을 스프링으로부터 반환 받는다.
     */
    @Test
    public void test_loginuser(){
        ModelUser result = new HttpLogin().loginuser("01", "01");
        assertEquals("01", result.getUserid());
        assertEquals("01", result.getuserpassword());
        assertEquals("하나", result.getUsername());
    }


    @Test
    public void test_idcheck(){
        String result = new HttpLogin().idcheck("aaa");
        assertEquals("1"   , result);
    }


    @Test
    public void test_insertuser(){

        String result = new HttpLogin().insertuser("bbb","bbb","bbb","bbb","bbb");
        assertEquals("1"   , result);
    }


    @Test
    public void test_edituser(){
        String result = new HttpLogin().edituser("bbb","ccc","ccc","ccc","ccc");
        assertEquals("1"   , result);
    }


    @Test
    public void test_outuser(){
        String result = new HttpLogin().outuser("aaa");
        assertEquals("1"   , result);
    }


}
