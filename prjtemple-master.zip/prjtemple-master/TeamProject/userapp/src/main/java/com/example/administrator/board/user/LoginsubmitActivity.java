package com.example.administrator.board.user;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.administrator.board.R;
import com.example.administrator.board.board.free_BoardActivity;
import com.example.administrator.board.board.qna_BoardActivity;
import com.example.administrator.board.model.ModelUser;

public class LoginsubmitActivity extends AppCompatActivity {

    private Bundle bundle;
    private ModelUser modelUser;
    private TextView name, tv_edtintent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginsubmit);

        // Q&A게시판, 자유게시판 글쓰러 가기
        Button btn_qnaboard, btn_freeboard;
        btn_qnaboard = (Button) findViewById(R.id.btn_qnaboard);
        btn_freeboard = (Button) findViewById(R.id.btn_freeboard);

        //로그인 사용자 이름 가져옴
        bundle = getIntent().getExtras();
        modelUser = bundle.getParcelable("data");
        name= (TextView) findViewById(R.id.tv_name);
        name.setText(modelUser.getUsername());

        //회원정보수정으로 이동
        tv_edtintent= (TextView) findViewById(R.id.tv_edtintent);
        tv_edtintent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginsubmitActivity.this, RegisterActivity.class);
                intent.putExtra("wherecome", 2);
                intent.putExtra("data", modelUser);
                    startActivityForResult(intent,10000);
            }
        });

        // Q&A게시판 글쓰러 가기
        btn_qnaboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginsubmitActivity.this, qna_BoardActivity.class);
                intent.putExtra("userid", modelUser);
                startActivity(intent);
            }
        });

        // 자유게시판 글쓰러 가기
        btn_freeboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginsubmitActivity.this, free_BoardActivity.class);
                intent.putExtra("userid", modelUser);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        bundle = getIntent().getExtras();
        modelUser = bundle.getParcelable("data");
        name= (TextView) findViewById(R.id.tv_name);
        name.setText(modelUser.getUsername());

    }
}


