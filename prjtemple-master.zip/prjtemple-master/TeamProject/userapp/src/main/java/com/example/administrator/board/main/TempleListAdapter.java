package com.example.administrator.board.main;

import android.content.Context;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.administrator.board.R;
import com.example.administrator.board.model.ModelTemple;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-08-01.
 */

public class TempleListAdapter extends ArrayAdapter<ModelTemple>  {

    public Context context = null;

    class ViewHolder {

        public TextView templecd;
        public TextView programtype;
        public TextView programname;
        public TextView maxperson;
        public TextView programdetail;
    }

    public TempleListAdapter(@NonNull Context context, @LayoutRes int resource, @IdRes int textViewResourceId, @NonNull List<ModelTemple> objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        View itemLayout = super.getView(position, convertView, parent);

        ViewHolder viewHolder = (ViewHolder) itemLayout.getTag();

        if (viewHolder == null) {

            viewHolder = new ViewHolder();
            //templeprogram 리스트 셋
            //viewHolder.programimage = (ImageView) itemLayout.findViewById(R.id.programimage);
            viewHolder.templecd = (TextView) itemLayout.findViewById(R.id.templecd);
            viewHolder.programtype = (TextView) itemLayout.findViewById(R.id.programtype);
            viewHolder.programname = (TextView) itemLayout.findViewById(R.id.programname);
            viewHolder.maxperson = (TextView) itemLayout.findViewById(R.id.maxperson);
            //templeinfo 셋
            itemLayout.setTag(viewHolder); // 한번 찾은 뷰를 저장해 둠 // 찾는 속도 최적화

        }

        //프로그램 리스트 셋
        //viewHolder.programimage.setText(this.getItem(position).getProgramimage());
        viewHolder.templecd.setText("사찰 이름 : "+this.getItem(position).getTemplecd());
        viewHolder.programtype.setText("프로그램 타입 : "+this.getItem(position).getProgramtype());
        viewHolder.programname.setText("프로그램 이름 : "+this.getItem(position).getProgramname());
        viewHolder.maxperson.setText("최대 인원 : "+this.getItem(position).getMaxperson());


        return itemLayout;
    }

}

