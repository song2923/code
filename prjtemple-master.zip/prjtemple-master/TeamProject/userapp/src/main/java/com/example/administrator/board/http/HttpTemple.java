package com.example.administrator.board.http;

import com.example.administrator.board.model.ModelTemple;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertEquals;

/**
 * Created by Administrator on 2017-08-16.
 */

public class HttpTemple {

    //TempleProgram 리스트를 불러오기위한 메서드
    public List<ModelTemple> getTempleProgramList(Integer start){

        //서버의 주소값
        String URL_ITEMLIST = "http://10.0.2.1:8080/templeprogramlist";

        HttpRequest request = null;
        JSONArray response = null;

        //반환 될 모델 리스트 생성
        List<ModelTemple> result = new ArrayList<>();

        try {
            //HttpRequest Header 추가
            request = new HttpRequest(URL_ITEMLIST).addHeader("charset", "utf-8");
            //Spring에서 받을 parameter 값 추가
            request.addParameter("start", String.valueOf(start) );

            //httpCode 를 이용하여 값 전송
            int httpCode = request.post();

            //전송이 잘 되었는지 확인
            if( httpCode == HttpURLConnection.HTTP_OK ){
                response = request.getJSONArrayResponse();
            }
            else {
                // error
            }

            //받은 값을 리스트의 크기에 맞추어 모델클래스에 set
            if (response != null) {
                for (int i=0; i<response.length(); i++){
                    JSONObject obj=(JSONObject)response.get(i);

                    ModelTemple item = new ModelTemple();
                    item.setProgramno(Integer.valueOf(obj.getString("programno")));
                    item.setTemplecd(obj.getString("templecd"));
                    item.setProgramtype(Integer.valueOf(obj.getString("programtype")));
                    item.setProgramname(obj.getString("programname"));
                    item.setMaxperson(Integer.valueOf(obj.getString("maxperson")));

                    result.add( item );
                }
            }
            else{

            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            request.close();
        }

        return result;
    }

    //programno을 spring 으로 보내어 Model로 반환
    public ModelTemple getTempleOne(Integer programno){

        String URL_TempleOne = "http://10.0.2.1:8080/getTempleOne";

        HttpRequest request = null;
        JSONObject response = null;

        ModelTemple result = new ModelTemple();

        try {
            request = new HttpRequest(URL_TempleOne).addHeader("charset", "utf-8");
            request.addParameter("programno", String.valueOf(programno));


            int httpCode = request.post();

            if( httpCode == HttpURLConnection.HTTP_OK ){
                response = request.getJSONObjectResponse();
            }
            else {
                // error
            }

            result.setTemplecd( response.getString("templecd") );
            result.setTempleaddr_postcode( response.getString("templeaddr_postcode") );
            result.setTempleaddr_road( response.getString("templeaddr_road") );
            result.setTempleaddr_jibun( response.getString("templeaddr_jibun") );
            result.setTemplephone( response.getString("templephone") );



        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            request.close();
        }

        String URL_TempleProgramOne = "http://10.0.2.1:8080/templeprogramone";

        try {
            request = new HttpRequest(URL_TempleProgramOne).addHeader("charset", "utf-8");
            request.addParameter("programno", String.valueOf(programno));


            int httpCode = request.post();

            if( httpCode == HttpURLConnection.HTTP_OK ){
                response = request.getJSONObjectResponse();
            }
            else {
                // error
            }

            result.setProgramno(Integer.valueOf(response.getString("programno")));
            result.setProgramtype(Integer.valueOf(response.getString("programtype")));
            result.setProgramname( response.getString("programname") );
            result.setProgramdetail( response.getString("programdetail") );
            result.setProgramprice(Integer.valueOf(response.getString("programprice")));
            result.setMaxperson(Integer.valueOf(response.getString("maxperson")));



        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            request.close();
        }


        return result;
    }

    //삭제하고 싶은 programno을 넘겨 delete가 잘 되었는지 Integer값으로 확인
    public Integer templeInfoDelete(Integer programno){

        String URL_TempleOne = "http://10.0.2.1:8080/templeInfoDelete";

        HttpRequest request = null;
        Integer response = null;

        Integer result = -1;

        try {
            request = new HttpRequest(URL_TempleOne).addHeader("charset", "utf-8");
            request.addParameter("programno", String.valueOf(programno));


            int httpCode = request.post();

            if( httpCode == HttpURLConnection.HTTP_OK ){
                response = Integer.parseInt(request.getStringResponse());
            }
            else {
                // error
            }
            result = response;

        } catch (IOException e) {
            e.printStackTrace();
        }  finally {
            request.close();
        }

        return result;
    }

    //update data를 map으로 넘기고 Update가 잘 되었는지 Integer값으로 확인
    public Integer templeInfoUpdate(Map<String, Object> map) {
        String URL_templeInfoUpdate = "http://10.0.2.1:8080/templeInfoUpdate";

        HttpRequest request = null;
        Integer response = null;

        Integer result =-1;
        try {
            request = new HttpRequest(URL_templeInfoUpdate).addHeader("charset", "utf-8")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Accept", "application/json");


            String data = new Gson().toJson(map);
            int httpCode = request.post(data);

            if( httpCode == HttpURLConnection.HTTP_OK ){
                response = Integer.parseInt(request.getStringResponse());
            }
            else {
                // error
            }
            result = response;
        } catch (IOException e) {
            e.printStackTrace();
        }  finally {
            request.close();
        }
        return result;
    }

    //update data를 map으로 넘기고 Update가 잘 되었는지 Integer값으로 확인
    public Integer templeProgramInfoUpdate(Map<String, Object> map) {
        String URL_templeInfoUpdate = "http://10.0.2.1:8080/templeProgramInfoUpdate";

        HttpRequest request = null;
        Integer response = null;

        Integer result =-1;
        try {
            request = new HttpRequest(URL_templeInfoUpdate).addHeader("charset", "utf-8")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Accept", "application/json");


            String data = new Gson().toJson(map);
            int httpCode = request.post(data);

            if( httpCode == HttpURLConnection.HTTP_OK ){
                response = Integer.parseInt(request.getStringResponse());
            }
            else {
                // error
            }
            result = response;
        } catch (IOException e) {
            e.printStackTrace();
        }  finally {
            request.close();
        }
        return result;
    }

    //Insert 할 Model 값을 넘겨 Integer값으로 확인
    public Integer templeInsert(ModelTemple model){

        String URL_TempleOne = "http://10.0.2.1:8080/insertTempleOne";

        HttpRequest request = null;
        Integer response = null;

        Integer result = -1;

        try {
            request = new HttpRequest(URL_TempleOne).addHeader("charset", "utf-8")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Accept", "application/json");

            String data = new Gson().toJson(model);
            int httpCode = request.post(data);

            if( httpCode == HttpURLConnection.HTTP_OK ){
                response = Integer.parseInt(request.getStringResponse());
            }
            else {
                // error
            }
            result = response;

        } catch (IOException e) {
            e.printStackTrace();
        }  finally {
            request.close();
        }

        return result;
    }

    //Insert 할 Model 값을 넘겨 Integer값으로 확인
    public Integer templeprogramInsert(ModelTemple model){

        String URL_TempleOne = "http://10.0.2.1:8080/insertTempleProgramOne";

        HttpRequest request = null;
        Integer response = null;

        Integer result = -1;

        try {
            request = new HttpRequest(URL_TempleOne).addHeader("charset", "utf-8")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Accept", "application/json");

            String data = new Gson().toJson(model);
            int httpCode = request.post(data);

            if( httpCode == HttpURLConnection.HTTP_OK ){
                response = Integer.parseInt(request.getStringResponse());
            }
            else {
                // error
            }
            result = response;

        } catch (IOException e) {
            e.printStackTrace();
        }  finally {
            request.close();
        }

        return result;
    }


}
