package com.example.administrator.board.main;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.content.Intent;

import com.example.administrator.board.R;
import com.example.administrator.board.http.HttpTemple;
import com.example.administrator.board.model.ModelTemple;

import java.util.ArrayList;
import java.util.List;



public class RegitListActivity extends AppCompatActivity {

    private ListView listView = null;
    private TempleListAdapter adapter = null;
    private boolean calling  = false;
    private List<ModelTemple> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regit_list);

        //ListView set
        listView = (ListView) findViewById(R.id.regit_listView);

        //ListView에 Adapter 연결
        list = new ArrayList<ModelTemple>();
        adapter = new TempleListAdapter(this, R.layout.list_view_item, R.id.programname, list);
        listView.setAdapter(adapter);

        //ListView Scroll이 움직일 때 이벤트 관리
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {


                // 마지막 항목이 완전히 보이는지 확인하기위한 계산 샘플.
                final int lastItem = firstVisibleItem + visibleItemCount;
                if(lastItem == totalItemCount) {
                    if( !calling ) {
                        calling = true;
                        //마지막 항목에 대한 여러번의 호출을 피하기 위한 코드
                        new HttpTempleList().execute(adapter.getCount(), adapter.getCount()+2);
                    }
                }
            }
        });


        //ListView의 Item 클릭시 이벤트 설정
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //ListView의 Item의 객체값을 정보페이지로 넘김
                Intent infointent = new Intent(RegitListActivity.this, TempleInfo.class);
                ModelTemple temple = list.get(position);
                infointent.putExtra("temple",temple);
                //startActivityForResult를 사용하여 TempleInfo를 종료시 onOptionsItemSelected 이벤트 발생
                startActivityForResult(infointent,10000);
            }
        });
    }

    //startActivityForResult의 Activity가 종료되면 값을 처리
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        new HttpTempleList().execute(adapter.getCount(), adapter.getCount()+2);
    }
    //Actionbar에서 우측 아이템 생성
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //R.menu의 layout 연결
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menutemple,menu);
        return true;
    }
    //Actionbar 우측의 Item 클릭이벤트
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        Intent optionintent = new Intent(RegitListActivity.this,InsertActivity.class);

        switch (item.getItemId()){
            //Insert 페이지의 Fragment에서 해당 페이지로 이동하기 위한 값을 보냄
            case R.id.insert_templeinfo:
                //Temple Insert 페이지로 이동
                optionintent.putExtra("showid", "1");
                startActivityForResult(optionintent,10000);
                break;
            case R.id.insert_templeprograminfo:
                //TempleProgram Insert 페이지로 이동
                optionintent.putExtra("showid", "2");
                startActivityForResult(optionintent,10000);
                break;
        }

        return super.onOptionsItemSelected(item);
    }


    public class HttpTempleList extends AsyncTask<Integer, Integer, List<ModelTemple>> {

        private ProgressDialog waitDlg = null;
        private boolean calling  = false;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //서버에 요청 동안 Wating dialog를 보여주도록 한다.
            waitDlg = new ProgressDialog( RegitListActivity.this );
            waitDlg.setMessage("불러오는 중");
            waitDlg.show();
        }

        @Override
        protected List<ModelTemple> doInBackground(Integer... params) {

            List<ModelTemple> list = new HttpTemple().getTempleProgramList(0);
            return list;

        }


        @Override
        protected void onPostExecute(List<ModelTemple> result) {
            super.onPostExecute(result);

            if( waitDlg != null ) {
                waitDlg.dismiss();
                waitDlg = null;
            }

            //서버 연결 성공 시
            calling = false;

            refresh(result);
        }

    }
    public void refresh(List<ModelTemple> model){
        adapter.clear();
        adapter.addAll(model);


        // 데이터 받아온 후 화면 다시 그리기
        adapter.notifyDataSetChanged();

    }

}
