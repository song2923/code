package com.example.administrator.board.main;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.TextView;

import com.example.administrator.board.R;
import com.example.administrator.board.http.HttpTemple;
import com.example.administrator.board.model.ModelTemple;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UpdateActivity extends AppCompatActivity {
    private TextView templecd;
    private EditText updatepostcode_et;
    private EditText updateroad_et;
    private EditText updatejibun_et;
    private EditText updatephone_et;
    private EditText updatetype_et;
    private EditText updatepname_et;
    private EditText updatedetail_et;
    private EditText updateprice_et;
    private EditText updatemaxperson_et;
    private Button btn_updatetemple;
    private Button btn_templeprogramudpate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        templecd      = (TextView) findViewById(R.id.tv_templecd);
        updatepostcode_et       = (EditText) findViewById(R.id.updatepostcode_et);
        updateroad_et       = (EditText) findViewById(R.id.updateroad_et);
        updatejibun_et      = (EditText) findViewById(R.id.updatejibun_et);
        updatephone_et      = (EditText) findViewById(R.id.updatephone_et);
        updatetype_et       = (EditText) findViewById(R.id.updatetype_et);
        updatedetail_et = (EditText) findViewById(R.id.updatedetail_et);
        updatepname_et      = (EditText) findViewById(R.id.updatepname_et);
        updateprice_et      = (EditText) findViewById(R.id.updateprice_et);
        updatemaxperson_et  = (EditText) findViewById(R.id.updatemaxperson_et);
        btn_updatetemple = (Button) findViewById(R.id.btn_templeupdate);
        btn_templeprogramudpate = (Button) findViewById(R.id.btn_templeprogramudpate);


        Intent intentupdate = getIntent();
        ModelTemple wheremodel = (ModelTemple) intentupdate.getSerializableExtra("temple");
        final String wheretemplecd = wheremodel.getTemplecd().toString();
        //사찰 정보 업데이트

        templecd.setText(wheretemplecd);

        btn_updatetemple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ModelTemple updateTemple = new ModelTemple();
                updateTemple.setTempleaddr_postcode(updatepostcode_et.getText().toString());
                updateTemple.setTempleaddr_road(updateroad_et.getText().toString());
                updateTemple.setTempleaddr_jibun(updatejibun_et.getText().toString());
                updateTemple.setTemplephone(updatephone_et.getText().toString());

                Map<String, Object> map = new HashMap<String, Object>();
                map.put("updateTemple",updateTemple);
                map.put("whereTemplecd",wheretemplecd);
                new HttpTempleInfoupdate().execute(map);
                finish();
            }
        });
        btn_templeprogramudpate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ModelTemple updateTempleProgram = new ModelTemple();

                updateTempleProgram.setProgramname(updatepname_et.getText().toString());
                updateTempleProgram.setProgramtype(Integer.valueOf(updatetype_et.getText().toString()));
                updateTempleProgram.setProgramdetail(updatedetail_et.getText().toString());
                updateTempleProgram.setProgramprice(Integer.valueOf(updateprice_et.getText().toString()));
                updateTempleProgram.setMaxperson(Integer.valueOf(updatemaxperson_et.getText().toString()));

                Map<String, Object> map = new HashMap<String, Object>();
                map.put("updateTemple",updateTempleProgram);
                map.put("whereTemplecd",wheretemplecd);
                new HttpTempleProgramInfoupdate().execute(map);
                finish();
            }
        });

    }

    //Temple 정보 Update Thread
    public class HttpTempleInfoupdate extends AsyncTask<Map<String, Object>, Integer, Integer> {

        private ProgressDialog waitDlg = null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            waitDlg = new ProgressDialog( UpdateActivity.this );
            waitDlg.setMessage("불러오는 중");
            waitDlg.show();
        }

        @Override
        protected Integer doInBackground(Map<String, Object>... params) {

            Integer result = new HttpTemple().templeInfoUpdate(params[0]);
            return result;

        }

        @Override
        protected void onPostExecute(Integer result) {
            super.onPostExecute(result);

            if( waitDlg != null ) {
                waitDlg.dismiss();
                waitDlg = null;
            }

            finish();

        }
    }

    public class HttpTempleProgramInfoupdate extends AsyncTask<Map<String, Object>, Integer, Integer> {

        private ProgressDialog waitDlg = null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            waitDlg = new ProgressDialog( UpdateActivity.this );
            waitDlg.setMessage("불러오는 중");
            waitDlg.show();
        }

        @Override
        protected Integer doInBackground(Map<String, Object>... params) {

            Integer result = new HttpTemple().templeProgramInfoUpdate(params[0]);
            return result;

        }

        @Override
        protected void onPostExecute(Integer result) {
            super.onPostExecute(result);

            if( waitDlg != null ) {
                waitDlg.dismiss();
                waitDlg = null;
            }

            finish();

        }
    }
}
