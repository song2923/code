package com.example.administrator.board.main;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

import com.example.administrator.board.R;
import com.example.administrator.board.http.HttpTemple;
import com.example.administrator.board.model.ModelTemple;

import java.util.ArrayList;
import java.util.List;

public class TempleInfo extends AppCompatActivity {

    public TextView templecdinfo;
    public TextView templeaddr_postcode;
    public TextView templeaddr_road;
    public TextView templeaddr_jibun;
    public TextView templephoneinfo;
    public TextView programdetailinfo;
    public TextView programpriceinfo;
    public TextView maxpersoninfo;
    public TextView programtypeinfo;
    public TextView programnameinfo;
    public AlertDialog.Builder alert_confirm;
    public AlertDialog alert;
    public Button btn_reservation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temple_info);

        //getIntent로 Model값 받기
        Intent intentinfo = getIntent();
        ModelTemple model = (ModelTemple) intentinfo.getSerializableExtra("temple");

        //UpdateActivity로 update 할 데이터 보냄
        Intent intentupdate = new Intent(this,UpdateActivity.class);
        intentupdate.putExtra("updatemodel",model);



        templecdinfo = (TextView) findViewById(R.id.txt_templecd);
        templeaddr_postcode = (TextView)findViewById(R.id.templeaddr_postcode);
        templeaddr_road = (TextView) findViewById(R.id.templeaddr_road);
        templeaddr_jibun = (TextView) findViewById(R.id.templeaddr_jibun);
        templephoneinfo =  (TextView) findViewById(R.id.txt_templephone);
        programtypeinfo = (TextView) findViewById(R.id.txt_programtype);
        programnameinfo = (TextView) findViewById(R.id.txt_programname);
        programdetailinfo = (TextView) findViewById(R.id.txt_programdetail);
        programpriceinfo = (TextView) findViewById(R.id.txt_programprice);
        maxpersoninfo = (TextView) findViewById(R.id.txt_maxperson);
        btn_reservation = (Button) findViewById(R.id.btn_reservation);

        //DB에서 처리할 where 조건 데이터 전송
        new HttpTempleInfo().execute(model.getProgramno());

        //예약버튼 구현중
        btn_reservation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    //업데이트 후 바뀐 정보로 갱신
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Intent intentinfo = getIntent();
        ModelTemple model = (ModelTemple) intentinfo.getSerializableExtra("temple");

        Intent intentupdate = new Intent(this,UpdateActivity.class);
        intentupdate.putExtra("updatemodel",model);

        new HttpTempleInfo().execute(model.getProgramno());
    }

    //Actionbar의 아이템 생성
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menutempleinfo,menu);
        return true;
    }
    //Actionbar의 아이템 이벤트 처리
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intentinfo = getIntent();
        final ModelTemple model = (ModelTemple) intentinfo.getSerializableExtra("temple");
        switch (item.getItemId()) {

            case R.id.info_del:
                //AlerDialog 생성
                alert_confirm = new AlertDialog.Builder(this);
                //AlerDialog를 사용하여 삭제 할것인지 확인
                alert_confirm.setMessage("삭제하시겠습니까?").setCancelable(false).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // 삭제 실행 메서드
                                new HttpTempleInfoDelete().execute(model.getProgramno());
                                Toast.makeText(getApplicationContext(),"삭제되었습니다.",Toast.LENGTH_SHORT).show();
                            }
                        }).setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //삭제 취소하여 다시 돌아감
                                Toast.makeText(getApplicationContext(),"취소되었습니다.",Toast.LENGTH_SHORT).show();
                                return;
                            }
                        });
                alert = alert_confirm.create();
                //AlerDialog를 띄움
                alert.show();
                break;
            case R.id.info_update:
                //수정페이지로 이동하기 위한 코딩
                Intent intent = new Intent(TempleInfo.this,UpdateActivity.class);
                intent.putExtra("temple",model);
                startActivityForResult(intent,10000);

                break;
        }

        return super.onOptionsItemSelected(item);
    }


    //정보페이지 update Thread
    public class HttpTempleInfo extends AsyncTask<Integer, Integer, ModelTemple> {

        private ProgressDialog waitDlg = null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            waitDlg = new ProgressDialog( TempleInfo.this );
            waitDlg.setMessage("불러오는 중");
            waitDlg.show();
        }

        @Override
        protected ModelTemple doInBackground(Integer... params) {

            ModelTemple model = new HttpTemple().getTempleOne(params[0]);
            return model;

        }

        @Override
        protected void onPostExecute(ModelTemple result) {
            super.onPostExecute(result);

            if( waitDlg != null ) {
                waitDlg.dismiss();
                waitDlg = null;
            }

            templecdinfo.setText("사찰 이름 : "+result.getTemplecd());
            templeaddr_postcode.setText("사찰 주소 : "+result.getTempleaddr_postcode());
            templeaddr_road.setText("사찰 길 : "+result.getTempleaddr_road());
            templeaddr_jibun.setText("사찰 상세주소 : "+result.getTempleaddr_jibun());
            templephoneinfo.setText("사찰 번호 : "+result.getTemplephone());

            programtypeinfo.setText("프로그램 타입 : "+result.getProgramtype());
            programnameinfo.setText("프로그램 이름 : "+result.getProgramname());
            programdetailinfo.setText("프로그램 설명 : "+result.getProgramdetail());
            programpriceinfo.setText("프로그램 가격 : "+result.getProgramprice());
            maxpersoninfo.setText("프로그램 수용 인원 : "+result.getMaxperson());


        }
    }

    //정보페이지 삭제 Thread
    public class HttpTempleInfoDelete extends AsyncTask<Integer, Integer, Integer> {

        private ProgressDialog waitDlg = null;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            waitDlg = new ProgressDialog( TempleInfo.this );
            waitDlg.setMessage("불러오는 중");
            waitDlg.show();
        }

        @Override
        protected Integer doInBackground(Integer... params) {

            Integer result = new HttpTemple().templeInfoDelete(params[0]);
            return result;

        }

        @Override
        protected void onPostExecute(Integer result) {
            super.onPostExecute(result);

            if( waitDlg != null ) {
                waitDlg.dismiss();
                waitDlg = null;
            }

            finish();

        }
    }

}

