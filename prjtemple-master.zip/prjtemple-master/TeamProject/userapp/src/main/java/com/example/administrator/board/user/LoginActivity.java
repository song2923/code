package com.example.administrator.board.user;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.board.R;
import com.example.administrator.board.http.HttpLogin;
import com.example.administrator.board.model.ModelUser;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    // 로그인화면

    private TextView tv_register;
    private EditText edt_id, edt_password;
    private Button btn_login;
    private String loginid, loginpasswd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edt_id = (EditText) findViewById(R.id.edt_id);
        edt_password = (EditText) findViewById(R.id.edt_password);

        btn_login = (Button) findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);

        tv_register = (TextView) findViewById(R.id.tv_register);
        tv_register.setOnClickListener(this);

    }


    //텍스트뷰 디자인
    public void onStart(){
        super.onStart();

        edt_id.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View view, boolean hasfocus) {
                if (hasfocus) {
                    view.setBackgroundResource(R.drawable.focus_border_style);
                } else {
                    view.setBackgroundResource(R.drawable.lost_focus_style);
                }
            }
        });

        edt_password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View view, boolean hasfocus) {
                if (hasfocus) {
                    view.setBackgroundResource(R.drawable.focus_border_style);
                } else {
                    view.setBackgroundResource(R.drawable.lost_focus_style);
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btn_login:
                loginid = edt_id.getText().toString();
                loginpasswd = edt_password.getText().toString();

                if(loginid.equals("")==true) {
                    Toast.makeText(LoginActivity.this, "아이디를 입력해주세요", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(loginpasswd.equals("")==true) {
                    Toast.makeText(LoginActivity.this, "비밀번호를 입력해주세요", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    // 입력 id, pw를 서버에 저장한다.
                    new HttpRequestAsyncTask().execute(loginid, loginpasswd);
                }

                break;

            // 회원가입을 누르면 회원가입 Activity로 이동한다.
            case R.id.tv_register:
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                intent.putExtra("wherecome", 1);
                startActivityForResult(intent,10000);
                break;
        }

    }

    public class HttpRequestAsyncTask extends AsyncTask<String, Integer, ModelUser> {
        ProgressDialog waitDlg = null;

        // 작업을 시작하기 전에 필요한 UI를 화면에 보여준다
//        @Override
//        protected void onPreExecute() {
//            super.onPreExecute();
//            waitDlg = new ProgressDialog(LoginActivity.this);
//            waitDlg.setMessage("로그인");
//            waitDlg.show();
//        }

        @Override
        protected ModelUser doInBackground(String... params) {

            String id = params[0];
            String password = params[1];

            ModelUser result = new HttpLogin().loginuser(id, password);

            return result;
        }


        @Override
        protected void onPostExecute(ModelUser result) {
            super.onPostExecute(result);

            // 프로그래스바 감추기
            if (waitDlg != null) {
                waitDlg.dismiss();
                waitDlg = null;
            }

            //서버 저장 성공 시
            if (result != null) {
                //받아온 정보를 modelUser에 저장한다.
                ModelUser modelUser = result;

                //메인화면으로 이동한다.
                Intent intent = new Intent();

                //메인화면에 받아온 정보를 보낸다.
                intent.putExtra("data", modelUser);
                setResult(RESULT_OK,intent);
                finish();

            }

            else{
                Toast.makeText(LoginActivity.this, "아이디 혹은 비밀번호가 다릅니다", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected void onCancelled(ModelUser s) {
            super.onCancelled(s);

            // 프로그래스바 감추기
            if (waitDlg != null) {
                waitDlg.dismiss();
                waitDlg = null;
            }
        }


    }


}