package com.example.administrator.board.model;

import android.content.Context;

import java.io.Serializable;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;

/**
 * Created by Administrator on 2017-08-01.
 */

public class ModelTemple implements Serializable {

    private String templecd;
    private Integer boardcd;
    private String boardname;
    private String title;
    private String content;
    private Integer hit;
    private Date nowdate;
    private Integer programno;
    private String programname;
    private Integer programtype;
    private String programdetail;
    private Integer programprice;
    private Integer maxperson;
    private Integer totalperson;
    private Date availabledate;
    private Date checkdate;
    private String templeaddr_postcode;
    private String templeaddr_road;
    private String templeaddr_jibun;
    private String templephone;
    private String userid;
    private String userpasswd;
    private Integer userno;
    private Integer userphone;
    private String useremail;
    private Integer attachfileno;
    private Integer articleno;
    private String filetype;
    private Integer filesize;
    private Integer commentno;

    // constructor
    public ModelTemple() {
    }

    // toString

    @Override
    public String toString() {
        return "ModelTemple{" +
                "templecd='" + templecd + '\'' +
                ", boardcd=" + boardcd +
                ", boardname='" + boardname + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", hit=" + hit +
                ", nowdate=" + nowdate +
                ", programno=" + programno +
                ", programname='" + programname + '\'' +
                ", programtype=" + programtype +
                ", programdetail='" + programdetail + '\'' +
                ", programprice=" + programprice +
                ", maxperson=" + maxperson +
                ", totalperson=" + totalperson +
                ", availabledate=" + availabledate +
                ", checkdate=" + checkdate +
                ", templeaddr_postcode='" + templeaddr_postcode + '\'' +
                ", templeaddr_road='" + templeaddr_road + '\'' +
                ", templeaddr_jibun='" + templeaddr_jibun + '\'' +
                ", templephone='" + templephone + '\'' +
                ", userid='" + userid + '\'' +
                ", userpasswd='" + userpasswd + '\'' +
                ", userno=" + userno +
                ", userphone=" + userphone +
                ", useremail='" + useremail + '\'' +
                ", attachfileno=" + attachfileno +
                ", articleno=" + articleno +
                ", filetype='" + filetype + '\'' +
                ", filesize=" + filesize +
                ", commentno=" + commentno +
                '}';
    }


    // getter & setter

    public String getTemplecd() {
        return templecd;
    }

    public void setTemplecd(String templecd) {
        this.templecd = templecd;
    }

    public Integer getBoardcd() {
        return boardcd;
    }

    public void setBoardcd(Integer boardcd) {
        this.boardcd = boardcd;
    }

    public String getBoardname() {
        return boardname;
    }

    public void setBoardname(String boardname) {
        this.boardname = boardname;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getHit() {
        return hit;
    }

    public void setHit(Integer hit) {
        this.hit = hit;
    }

    public Date getNowdate() {
        return nowdate;
    }

    public void setNowdate(Date nowdate) {
        this.nowdate = nowdate;
    }

    public Integer getProgramno() {
        return programno;
    }

    public void setProgramno(Integer programno) {
        this.programno = programno;
    }

    public String getProgramname() {
        return programname;
    }

    public void setProgramname(String programname) {
        this.programname = programname;
    }

    public Integer getProgramtype() {
        return programtype;
    }

    public void setProgramtype(Integer programtype) {
        this.programtype = programtype;
    }

    public String getProgramdetail() {
        return programdetail;
    }

    public void setProgramdetail(String programdetail) {
        this.programdetail = programdetail;
    }

    public Integer getProgramprice() {
        return programprice;
    }

    public void setProgramprice(Integer programprice) {
        this.programprice = programprice;
    }

    public Integer getMaxperson() {
        return maxperson;
    }

    public void setMaxperson(Integer maxperson) {
        this.maxperson = maxperson;
    }

    public Integer getTotalperson() {
        return totalperson;
    }

    public void setTotalperson(Integer totalperson) {
        this.totalperson = totalperson;
    }

    public Date getAvailabledate() {
        return availabledate;
    }

    public void setAvailabledate(Date availabledate) {
        this.availabledate = availabledate;
    }

    public Date getCheckdate() {
        return checkdate;
    }

    public void setCheckdate(Date checkdate) {
        this.checkdate = checkdate;
    }

    public String getTempleaddr_postcode() {
        return templeaddr_postcode;
    }

    public void setTempleaddr_postcode(String templeaddr_postcode) {
        this.templeaddr_postcode = templeaddr_postcode;
    }

    public String getTempleaddr_road() {
        return templeaddr_road;
    }

    public void setTempleaddr_road(String templeaddr_road) {
        this.templeaddr_road = templeaddr_road;
    }

    public String getTempleaddr_jibun() {
        return templeaddr_jibun;
    }

    public void setTempleaddr_jibun(String templeaddr_jibun) {
        this.templeaddr_jibun = templeaddr_jibun;
    }

    public String getTemplephone() {
        return templephone;
    }

    public void setTemplephone(String templephone) {
        this.templephone = templephone;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUserpasswd() {
        return userpasswd;
    }

    public void setUserpasswd(String userpasswd) {
        this.userpasswd = userpasswd;
    }

    public Integer getUserno() {
        return userno;
    }

    public void setUserno(Integer userno) {
        this.userno = userno;
    }

    public Integer getUserphone() {
        return userphone;
    }

    public void setUserphone(Integer userphone) {
        this.userphone = userphone;
    }

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }

    public Integer getAttachfileno() {
        return attachfileno;
    }

    public void setAttachfileno(Integer attachfileno) {
        this.attachfileno = attachfileno;
    }

    public Integer getArticleno() {
        return articleno;
    }

    public void setArticleno(Integer articleno) {
        this.articleno = articleno;
    }

    public String getFiletype() {
        return filetype;
    }

    public void setFiletype(String filetype) {
        this.filetype = filetype;
    }

    public Integer getFilesize() {
        return filesize;
    }

    public void setFilesize(Integer filesize) {
        this.filesize = filesize;
    }

    public Integer getCommentno() {
        return commentno;
    }

    public void setCommentno(Integer commentno) {
        this.commentno = commentno;
    }
}
