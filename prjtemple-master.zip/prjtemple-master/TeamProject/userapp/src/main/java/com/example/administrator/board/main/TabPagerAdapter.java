package com.example.administrator.board.main;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;


class TabPagerAdapter extends FragmentPagerAdapter{
    // tab 갯수
    private int tabCount = 0;


    public TabPagerAdapter(FragmentManager fm, int tabCount) {
        super(fm);
        this.tabCount = tabCount;
    }

    //Adapter와 Fragment 클래스 연결
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        switch (position){
            case 0:
                fragment = new InsertActivity.Insert_Fragment1();
                break;
            case 1:
                fragment = new InsertActivity.Insert_Fragment2();
                break;

        }

        return fragment;
    }

    //Fragment 갯수 확인
    @Override
    public int getCount() {
        return tabCount;
    }
}
