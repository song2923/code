package com.example.administrator.board.main;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.board.R;
import com.example.administrator.board.board.free_BoardActivity;
import com.example.administrator.board.board.qna_BoardActivity;
import com.example.administrator.board.model.ModelUser;
import com.example.administrator.board.user.LoginActivity;
import com.example.administrator.board.user.RegisterActivity;

import static com.example.administrator.board.R.menu.main;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private Bundle bundle;
    private ModelUser modelUser;
    private Intent intent = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                Intent intent = new Intent(MainActivity.this,InsertActivity.class);
                intent.putExtra("showid","1");
                startActivity(intent);
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        getSupportActionBar().setIcon(R.drawable.logo01);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        Intent intent =null;
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.nav_Login) {
            intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivityForResult(intent,999);
        } else if (id == R.id.nav_Edit) {
            intent = new Intent(MainActivity.this, RegisterActivity.class);
            intent.putExtra("wherecome", 2);
            intent.putExtra("data", modelUser);
            startActivityForResult(intent,999);

        } else if (id == R.id.nav_Logout) {
            modelUser.setUserid(null);

            NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
            if (navigationView != null) {
                Menu menu = navigationView.getMenu();
                menu.findItem(R.id.nav_Login).setVisible(true);
                menu.findItem(R.id.nav_Logout).setVisible(false);
                menu.findItem(R.id.nav_Edit).setVisible(false);
            }

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void onClick(View view) {
        ModelUser user = new ModelUser();

        switch (view.getId()){


            //검색 버튼
            case R.id.btn_list:

                intent = new Intent(this, RegitListActivity.class);
                startActivity(intent);

                break;

            case R.id.btn_map:
                Toast.makeText(getApplicationContext(),"준비중입니다.",Toast.LENGTH_SHORT).show();

                break;

            case R.id.btn_reser:
                Toast.makeText(getApplicationContext(),"준비중입니다.",Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn_board:
                intent = new Intent(this,free_BoardActivity.class);
                intent.putExtra("data", modelUser);
                startActivity(intent);
                break;

            case R.id.btn_question:
                intent = new Intent(this,qna_BoardActivity.class);
                intent.putExtra("data", modelUser);
                startActivity(intent);
                break;
            //최근 등록 된 프로그램
            case R.id.img_regist1:

                break;
            case R.id.img_regist2:
                break;
            case R.id.img_regist3:
                break;

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 999) {
            if (resultCode == RESULT_OK) {
                modelUser = data.getParcelableExtra("data");

                NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
                if (navigationView != null) {
                    Menu menu = navigationView.getMenu();
                    menu.findItem(R.id.nav_Login).setVisible(false);
                    menu.findItem(R.id.nav_Logout).setVisible(true);
                    menu.findItem(R.id.nav_Edit).setVisible(true);
                }

            }
        }

    }
}
