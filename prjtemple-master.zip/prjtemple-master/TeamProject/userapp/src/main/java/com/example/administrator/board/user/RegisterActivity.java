package com.example.administrator.board.user;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.board.R;
import com.example.administrator.board.http.HttpLogin;
import com.example.administrator.board.main.MainActivity;
import com.example.administrator.board.model.ModelUser;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    //회원가입 & 회원정보수정 Activity

    private EditText edt_id, edt_password, edt_loginpassword, edt_edtpassword, edt_name, edt_phone, edt_emailid, edt_righting;
    private TextView tv_edit, tv_register, tv_out;
    private Button btn_submit, btn_idcheck, btn_edit;
    private ArrayList emaillist;
    private Spinner spinner;
    private ModelUser modelUser;
    private Integer idok=0, emailget = 0;
    private Bundle bundle;
    private String userid, originalpassword, loginpassword, edtpassword, username, userphone, useremailid, usermailurl, useremail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        tv_edit = (TextView) findViewById(R.id.edit);
        tv_register = (TextView) findViewById(R.id.register);

        //글자수 제한 필터
        InputFilter[] LengthFilter15 = new InputFilter[1];
        LengthFilter15[0] = new InputFilter.LengthFilter(15);
        InputFilter[] LengthFilter30 = new InputFilter[1];
        LengthFilter15[0] = new InputFilter.LengthFilter(30);
        InputFilter[] LengthFilter11 = new InputFilter[1];
        LengthFilter15[0] = new InputFilter.LengthFilter(11);


        edt_id = (EditText) findViewById(R.id.edt_id);
        edt_id.setFilters(new InputFilter[]{filterAlphaNum                   //아이디에는 영문+숫자만 입력받는다
                        , new InputFilter.LengthFilter(15)});                //글자수 제한 (15자)

        edt_password = (EditText) findViewById(R.id.edt_password);
        edt_loginpassword = (EditText) findViewById(R.id.edt_loginpassword); //회원정보 수정- 기존 비밀번호 입력 박스
        edt_edtpassword = (EditText) findViewById(R.id.edt_edtpassword);     //회원정보 수정- 수정할 비밀번호 박스
        edt_password.setFilters(LengthFilter15);                             //글자수 제한 (15자)
        edt_password.setFilters(LengthFilter15);                             //글자수 제한 (15자)
        edt_edtpassword.setFilters(LengthFilter15);                          //글자수 제한 (15자)

        edt_name = (EditText) findViewById(R.id.edt_name);
        edt_name.setFilters(new InputFilter[]{filterKor                      //이름에는 한글만 입력받는다
                          , new InputFilter.LengthFilter(15)});              //글자수 제한 (15자)

        edt_phone = (EditText) findViewById(R.id.edt_phone);

        edt_emailid = (EditText) findViewById(R.id.edt_email);               //메일아이디 입력박스
        edt_righting = (EditText) findViewById(R.id.edt_righting);           //메일주소 직접입력 박스
        edt_righting.setEnabled(false);

        btn_submit = (Button) findViewById(R.id.btn_submit);                 //회원가입버튼
        btn_idcheck = (Button) findViewById(R.id.btn_idcheck);               //아이디중복확인버튼
        btn_edit = (Button) findViewById(R.id.btn_edit);                     //회원정보수정버튼
        tv_out = (TextView) findViewById(R.id.tv_out);                       //회원탈퇴버튼

        //메일주소를 스피너로 선택받음
        emaillist = new ArrayList<String>();
        emaillist.add("");
        emaillist.add("hanmail.net");
        emaillist.add("naver.com");
        emaillist.add("nate.com");
        emaillist.add("gmail.com");
        emaillist.add("직접입력");

        spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> emailAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, emaillist);
        spinner.setAdapter(emailAdapter);
        spinner.setOnItemSelectedListener(emailselected);


        //아이디 중복확인 클릭시
        btn_idcheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userid = edt_id.getText().toString();
                new HttpRequestAsyncTaskidcheck().execute(userid);
            }
        });


        //회원가입 클릭시
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userid = edt_id.getText().toString();
                String userpassword = edt_password.getText().toString();
                String username = edt_name.getText().toString();
                String userphone = edt_phone.getText().toString();
                String useremail = edt_emailid.getText().toString() + "\u0040" + edt_righting.getText().toString();

                if (userid.getBytes().length <= 0) {
                    Toast.makeText(RegisterActivity.this, "아이디를 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else if (userpassword.getBytes().length <= 0) {
                    Toast.makeText(RegisterActivity.this, "비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else if (username.getBytes().length <= 0) {
                    Toast.makeText(RegisterActivity.this, "이름을 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else if (userphone.getBytes().length <= 0) {
                    Toast.makeText(RegisterActivity.this, "핸드폰번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else if (edt_emailid.length() <= 0) {
                    Toast.makeText(RegisterActivity.this, "이메일 아이디를 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else if (edt_righting.length() <= 0) {
                    Toast.makeText(RegisterActivity.this, "이메일 주소를 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else if (idok!=10){
                    Toast.makeText(RegisterActivity.this, "아이디 중복검사를 해주세요.", Toast.LENGTH_SHORT).show();
                }
                else {
                    // 회원가입 입력정보 서버 저장
                    new HttpRequestAsyncTask().execute(userid, userpassword, username, userphone, useremail);
                    idok=0;
                }
            }
        });


        //회원정보수정 레이아웃을 보여준다.
        Intent intent = getIntent();
        int wherecome = intent.getExtras().getInt("wherecome");

        if (wherecome == 2) {

            tv_edit.setVisibility(tv_edit.VISIBLE);
            tv_register.setVisibility(tv_register.GONE);

            //로그인 사용자 정보를 ModelUser에 넣는다
            bundle = getIntent().getExtras();
            modelUser = bundle.getParcelable("data");

            //현재 로그인한 아이디 보여주기 (수정불가능)
            edt_id.setText(modelUser.getUserid());
            edt_id.setEnabled(false);

            //기존비밀번호 입력받고 수정할 비밀번호 입력받기
            edt_password.setVisibility(edt_password.GONE);
            edt_loginpassword.setVisibility(edt_loginpassword.VISIBLE);
            edt_edtpassword.setVisibility(edt_edtpassword.VISIBLE);

            //현재 로그인한 회원의 이름을 가져온다.
            edt_name.setText(modelUser.getUsername());

            //현재 로그인한 회원의 핸드폰번호를 가져온다.
            edt_phone.setText(modelUser.getUserphone());

            //현재 로그인한 회원의 이메일을 가져온다.
            int e = modelUser.getUseremail().indexOf("\u0040");
            String id = modelUser.getUseremail().substring(0, e);
            String mail = modelUser.getUseremail().substring(e + 1, modelUser.getUseremail().length());
            edt_emailid.setText(id);
            edt_righting.setText(mail);

            btn_idcheck.setVisibility(edt_id.GONE);             //아이디중복확인버튼 비활성화
            btn_submit.setVisibility(btn_submit.GONE);          //가입버튼 비활성화
            btn_edit.setVisibility(btn_edit.VISIBLE);           //회원정보수정버튼 활성화
            tv_out.setVisibility(tv_out.VISIBLE);               //탈퇴버튼 활성화

            //메일주소가 목록에 있으면 해당 스피너값을 선택한다
            for (int i = 0; i <= 5; i = i + 1) {
                String getemail = String.valueOf(emaillist.get(i));
                if (getemail.equals(mail) == true) {
                    spinner.setAdapter(emailAdapter);
                    spinner.setOnItemSelectedListener(emailselected);
                    spinner.setSelection(i);
                    emailAdapter.notifyDataSetChanged();
                } else {
                    emailget = emailget + 1;
                }
            }
            //메일주소가 목록에 없으면 0번 스피너에 해당 값을 추가하고 선택한다
            if (emailget == 6) {
                spinner.setAdapter(emailAdapter);
                emaillist.set(0, mail);
                spinner.setSelection(0);
                emailAdapter.notifyDataSetChanged();
            }
        }

        //회원가입 레이아웃을 보여준다.
        else if (wherecome == 1) {
            tv_register.setVisibility(tv_register.VISIBLE);
            tv_edit.setVisibility(tv_edit.GONE);
            edt_id.setEnabled(true);
            edt_password.setVisibility(edt_password.VISIBLE);
            edt_loginpassword.setVisibility(edt_loginpassword.GONE);
            edt_edtpassword.setVisibility(edt_edtpassword.GONE);
            btn_idcheck.setVisibility(edt_id.VISIBLE);
            btn_submit.setVisibility(btn_submit.VISIBLE);
            btn_edit.setVisibility(btn_edit.GONE);
            tv_out.setVisibility(tv_out.GONE);
        }

        //회원정보 수정 클릭시
        btn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                userid = edt_id.getText().toString();
                originalpassword = modelUser.getuserpassword().toString();
                loginpassword = edt_loginpassword.getText().toString();
                edtpassword = edt_edtpassword.getText().toString();
                username = edt_name.getText().toString();
                userphone = edt_phone.getText().toString();
                useremailid = edt_emailid.getText().toString();
                usermailurl = edt_righting.getText().toString();
                useremail =useremailid + "\u0040" + usermailurl;

                if (useremailid.equals("") == true) {
                    Toast.makeText(RegisterActivity.this, "이메일을 확인해주세요", Toast.LENGTH_SHORT).show();
                }
                else if (usermailurl.equals("") == true) {
                    Toast.makeText(RegisterActivity.this, "이메일을 확인해주세요", Toast.LENGTH_SHORT).show();
                }
                else if (originalpassword.equals(loginpassword) != true) {
                    Toast.makeText(RegisterActivity.this, "기존 비밀번호를 확인해주세요", Toast.LENGTH_SHORT).show();
                }
                else if (edtpassword.getBytes().length <= 0) {
                    // 서버 저장
                    new HttpRequestAsyncTaskedit().execute(userid, originalpassword, username, userphone, useremail);
                } else {
                    // 서버 저장
                    new HttpRequestAsyncTaskedit().execute(userid, edtpassword, username, userphone, useremail);
                }
            }
        });


        //회원탈퇴 클릭시
        tv_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder alert_confirm = new AlertDialog.Builder(RegisterActivity.this);
                alert_confirm.setMessage("정말 탈퇴하시겠습니까?").setCancelable(false).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String userid = edt_id.getText().toString();
                                new HttpRequestAsyncTaskout().execute(userid);
                            }
                        }).setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                return;
                            }
                        });
                final AlertDialog alert = alert_confirm.create();
                alert.setOnShowListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface arg0) {
                        alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#4ba401"));
                    }
                });
                alert.show();
            }
        });
    }

    // 스타일..ㅎ
    public void onStart(){
        super.onStart();

        edt_id.setOnFocusChangeListener( new View.OnFocusChangeListener(){
            public void onFocusChange( View view, boolean hasfocus){
                if(hasfocus){view.setBackgroundResource( R.drawable.focus_border_style);}
                else{view.setBackgroundResource( R.drawable.lost_focus_style);}            }
        });
        edt_password.setOnFocusChangeListener( new View.OnFocusChangeListener(){
            public void onFocusChange( View view, boolean hasfocus){
                if(hasfocus){view.setBackgroundResource( R.drawable.focus_border_style);}
                else{view.setBackgroundResource( R.drawable.lost_focus_style);}           }
        });
        edt_loginpassword.setOnFocusChangeListener( new View.OnFocusChangeListener(){
            public void onFocusChange( View view, boolean hasfocus){
                if(hasfocus){view.setBackgroundResource( R.drawable.focus_border_style);}
                else{view.setBackgroundResource( R.drawable.lost_focus_style);}           }
        });
        edt_edtpassword.setOnFocusChangeListener( new View.OnFocusChangeListener(){
            public void onFocusChange( View view, boolean hasfocus){
                if(hasfocus){view.setBackgroundResource( R.drawable.focus_border_style);}
                else{view.setBackgroundResource( R.drawable.lost_focus_style);}           }
        });
        edt_name.setOnFocusChangeListener( new View.OnFocusChangeListener(){
            public void onFocusChange( View view, boolean hasfocus){
                if(hasfocus){view.setBackgroundResource( R.drawable.focus_border_style);}
                else{view.setBackgroundResource( R.drawable.lost_focus_style);}           }
        });
        edt_phone.setOnFocusChangeListener( new View.OnFocusChangeListener(){
            public void onFocusChange( View view, boolean hasfocus){
                if(hasfocus){view.setBackgroundResource( R.drawable.focus_border_style);}
                else{view.setBackgroundResource( R.drawable.lost_focus_style);}           }
        });
        edt_emailid.setOnFocusChangeListener( new View.OnFocusChangeListener(){
            public void onFocusChange( View view, boolean hasfocus){
                if(hasfocus){view.setBackgroundResource( R.drawable.focus_border_style);}
                else{view.setBackgroundResource( R.drawable.lost_focus_style);}           }
        });
        edt_righting.setOnFocusChangeListener( new View.OnFocusChangeListener(){
            public void onFocusChange( View view, boolean hasfocus){
                if(hasfocus){view.setBackgroundResource( R.drawable.focus_border_style);}
                else{view.setBackgroundResource( R.drawable.lost_focus_style);}           }
        });

    }



    //한글만 입력
    public InputFilter filterKor = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Pattern ps = Pattern.compile("^[ㄱ-ㅣ가-힣]*$");
            if (!ps.matcher(source).matches()) {
                return "";
            }
            return null;
        }
    };

    //영문+숫자만 입력
    public InputFilter filterAlphaNum = new InputFilter() {
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Pattern ps = Pattern.compile("^[a-zA-Z0-9]*$");
            if (!ps.matcher(source).matches()) {
                return "";
            }
            return null;
        }
    };


    //스피너- 메일주소를 선택하면 editbox 자동입력
    AdapterView.OnItemSelectedListener emailselected = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            for (int y = 0; y <= 5; y = y + 1) {
                if (position < 5){
                    edt_righting.setEnabled(false);
                    String Item = (String) emaillist.get(position);
                    edt_righting.setText(Item);

                }
                if (position == 5) {
                    edt_righting.setEnabled(true);
                    edt_righting.setText("");
                }
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
        }
    };


    //★★★idcheck(아이디중복확인) HTTP통신★★★
    public class HttpRequestAsyncTaskidcheck extends AsyncTask<String, Integer, String> {
        ProgressDialog waitDlg = null;

        // 작업을 시작하기 전에 필요한 UI를 화면에 보여준다
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            waitDlg = new ProgressDialog(RegisterActivity.this);
            waitDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            String userid = params[0];
            String result = new HttpLogin().idcheck(userid);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            // 프로그래스바 감추기
            if (waitDlg != null) {
                waitDlg.dismiss();
                waitDlg = null;
            }
            AlertDialog.Builder alert_confirm = new AlertDialog.Builder(RegisterActivity.this);

            //서버 저장 성공 시
            if (s.equals("1")) {
                alert_confirm.setMessage("이미 사용중인 아이디입니다.").setCancelable(false).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                return;
                            }
                        });
                final AlertDialog alert = alert_confirm.create();
                alert.setOnShowListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface arg0) {
                        alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#4ba401"));
                    }
                });
                alert.show();
            } else {
                alert_confirm.setMessage("사용 가능한 아이디입니다.").setCancelable(false).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                idok = 10;
                                return;
                            }
                        });
                final AlertDialog alert = alert_confirm.create();
                alert.setOnShowListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface arg0) {
                        alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#4ba401"));
                        ;
                    }
                });
                alert.show();
            }

        }
    }

    //★★★insret(회원가입) HTTP통신★★★
    public class HttpRequestAsyncTask extends AsyncTask<String, Integer, String> {
        ProgressDialog waitDlg = null;

        // 작업을 시작하기 전에 필요한 UI를 화면에 보여준다
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            waitDlg = new ProgressDialog(RegisterActivity.this);
            waitDlg.setMessage("회원가입");
            waitDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {

            String userid = params[0];
            String userpassword = params[1];
            String username = params[2];
            String userphone = params[3];
            String useremail = params[4];

            String result = new HttpLogin().insertuser(userid, userpassword, username, userphone, useremail);

            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            // 프로그래스바 감추기
            if (waitDlg != null) {
                waitDlg.dismiss();
                waitDlg = null;
            }

            //서버 저장 성공 시
            if (s.equals("1")) {
                Toast.makeText(RegisterActivity.this, "로그인화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }

    //★★★eidt(회원정보수정) HTTP통신★★★
    public class HttpRequestAsyncTaskedit extends AsyncTask<String, Integer, String> {
        ProgressDialog waitDlg = null;

        @Override
        // 작업을 시작하기 전에 필요한 UI를 화면에 보여준다
        protected void onPreExecute() {
            super.onPreExecute();

            waitDlg = new ProgressDialog(RegisterActivity.this);
            waitDlg.setMessage("회원정보수정");
            waitDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            String userid = params[0];
            String userpassword = params[1];
            String username = params[2];
            String userphone = params[3];
            String useremail = params[4];

            String result = new HttpLogin().edituser(userid, userpassword, username, userphone, useremail);

            return result;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            // 프로그래스바 감추기
            if (waitDlg != null) {
                waitDlg.dismiss();
                waitDlg = null;
            }
            if (edtpassword.getBytes().length <= 0) {
                // 서버 저장
                new HttpRequestAsyncTaskrelogin().execute(userid, originalpassword);
            } else {
                // 서버 저장
                new HttpRequestAsyncTaskrelogin().execute(userid, edtpassword);
            }
        }
    }

    //★★★out(회원탈퇴) HTTP통신★★★
    public class HttpRequestAsyncTaskout extends AsyncTask<String, Integer, String> {
        ProgressDialog waitDlg = null;

        @Override
        // 작업을 시작하기 전에 필요한 UI를 화면에 보여준다
        protected void onPreExecute() {
            super.onPreExecute();

            waitDlg = new ProgressDialog(RegisterActivity.this);
            waitDlg.setMessage("회원탈퇴");
            waitDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {

            String userid = params[0];
            String result = new HttpLogin().outuser(userid);

            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            // 프로그래스바 감추기
            if (waitDlg != null) {
                waitDlg.dismiss();
                waitDlg = null;
            }

            //서버 저장 성공 시
            if (s.equals("1")) {
                Toast.makeText(RegisterActivity.this, "메인화면으로 돌아갑니다", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }




    //★★★relogin(수정후 업데이트를 위한 재로그인) HTTP통신★★★
    public class HttpRequestAsyncTaskrelogin extends AsyncTask<String, Integer, ModelUser> {
        ProgressDialog waitDlg = null;

        // 작업을 시작하기 전에 필요한 UI를 화면에 보여준다
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            waitDlg = new ProgressDialog(RegisterActivity.this);
            waitDlg.setMessage("정보 업데이트중");
            waitDlg.show();
        }

        @Override
        protected ModelUser doInBackground(String... params) {

            String id = params[0];
            String password = params[1];

            ModelUser result = new HttpLogin().loginuser(id, password);

            return result;
        }


        @Override
        protected void onPostExecute(ModelUser result) {
            super.onPostExecute(result);

            // 프로그래스바 감추기
            if (waitDlg != null) {
                waitDlg.dismiss();
                waitDlg = null;
            }

            //서버 저장 성공 시
            if (result != null) {
                //받아온 정보를 modelUser에 저장한다.
                ModelUser modelUser = result;

                //메인화면으로 이동한다.
                Intent intent = new Intent();
                //메인화면에 받아온 정보를 보낸다.
                intent.putExtra("data", modelUser);
                setResult(RESULT_OK,intent);
                finish();

            }

        }

        @Override
        protected void onCancelled(ModelUser s) {
            super.onCancelled(s);

            // 프로그래스바 감추기
            if (waitDlg != null) {
                waitDlg.dismiss();
                waitDlg = null;
            }
        }


    }

}

