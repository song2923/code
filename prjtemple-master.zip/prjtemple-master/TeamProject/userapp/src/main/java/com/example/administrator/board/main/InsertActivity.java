package com.example.administrator.board.main;

import android.app.ProgressDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;

import com.example.administrator.board.R;
import com.example.administrator.board.http.HttpTemple;
import com.example.administrator.board.model.ModelTemple;


public class InsertActivity extends AppCompatActivity {

    private FragmentTransaction transaction = null;
    public Integer REQUEST_CODE = 8573;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);


        // TabLayout 초기화
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.setBackgroundColor(Color.parseColor("#bfdfe0"));
        tabLayout.setTabTextColors(ColorStateList.valueOf(Color.BLACK));

        tabLayout.addTab(tabLayout.newTab().setText("사찰정보 추가"));
        tabLayout.addTab(tabLayout.newTab().setText("프로그램 추가"));

        // ViewPager 초기화
        final ViewPager viewPager = (ViewPager) findViewById(R.id.view_pager);

        // PagerAdater 생성
        TabPagerAdapter pagerAdapter = new TabPagerAdapter(getSupportFragmentManager(), tabLayout.getTabCount());

        // PagerAdapter와 ViewPager 연결 : Fragment와 ViewPager 연결
        viewPager.setAdapter(pagerAdapter);

        // ViewPager의 OnPageChangeListener 리스너 설정 : TabLayout과 ViewPager
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        // RegitListActivity 에서 onOptionsItemSelected의 버튼 id값으로 Fragment 페이지 설정
        Intent intent = getIntent();
        String check = intent.getStringExtra("showid");
        if (check.equals("1")) {
            viewPager.setCurrentItem(0);
        } else if (check.equals("2")) {
            viewPager.setCurrentItem(1);

        }
        // 탭 값 유지
        viewPager.setOffscreenPageLimit(1);

        // TabSelectedListener 설정 : 화면에서 tab을 클릭할때
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

    }

    //첫번째 Fragment 내부 클래스
    static class Insert_Fragment1 extends Fragment {
        private View rootView = null;
        private Button btnsave = null;
        private EditText templecd_et = null;
        private EditText postcode_et = null;
        private EditText road_et = null;
        private EditText jibun_et = null;
        private EditText phone_et = null;


        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            rootView = inflater.inflate(R.layout.insert_fragment1, container, false);
            btnsave = (Button) rootView.findViewById(R.id.btn_insertsave);
            templecd_et = (EditText) rootView.findViewById(R.id.btn_insert_templecd);
            postcode_et = (EditText) rootView.findViewById(R.id.btn_insert_postcode);
            road_et = (EditText) rootView.findViewById(R.id.btn_insert_road);
            jibun_et = (EditText) rootView.findViewById(R.id.btn_insert_jibun);
            phone_et = (EditText) rootView.findViewById(R.id.btn_insert_phone);


            btnsave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    // Temple 정보 Insert
                    ModelTemple model = new ModelTemple();
                    model.setTemplecd(templecd_et.getText().toString());
                    model.setTempleaddr_postcode(postcode_et.getText().toString());
                    model.setTempleaddr_road(road_et.getText().toString());
                    model.setTempleaddr_jibun(jibun_et.getText().toString());
                    model.setTemplephone(phone_et.getText().toString());

                    //Spring으로 데이터를 전송하기위해 AsyncTask의 Thread 사용
                    new HttpTempleInsert().execute(model);
                    //Insert 데이터를 보내고 현재 Activity 종료
                    getActivity().finish();
                }

            });
            return rootView;
        }
        //AsyncTask로 Thread를 실행하여 전송값,진행값,리턴값을 처리
        public class HttpTempleInsert extends AsyncTask<ModelTemple, Integer, Integer> {

            private ProgressDialog waitDlg = null;

            //Thread 실행전 준비
            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                //서버에 요청 동안 Wating dialog를 보여주도록 한다.
                waitDlg = new ProgressDialog(getContext());
                waitDlg.setMessage("불러오는 중");
                waitDlg.show();
            }
            //Thread 실행
            @Override
            protected Integer doInBackground(ModelTemple... params) {
                //doInBackground로
                Integer result = new HttpTemple().templeInsert(params[0]);
                return result;

            }
            //Thread를 마치고 result를 retune
            @Override
            protected void onPostExecute(Integer result) {
                super.onPostExecute(result);

                //서버 요청 완료 후 Waiting dialog를 제거한다.
                if (waitDlg != null) {
                    waitDlg.dismiss();
                    waitDlg = null;
                }
            }
        }
    }
    //두번째 Fragment 내부 클래스
    //Fragment1과 동일하게 처리하여 TempleProgram을 DB에 Insert
    static class Insert_Fragment2 extends Fragment {
        private View rootView = null;

        private Button btnsave2 = null;
        private EditText templecd_et = null;
        private EditText programtype_et = null;
        private EditText programname_et = null;
        private EditText programprice_et = null;
        private EditText programdetail_et = null;
        private EditText maxperson_et = null;


        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            rootView = inflater.inflate(R.layout.insert_fragment2, container, false);

            btnsave2 = (Button) rootView.findViewById(R.id.btn_insertsave2);
            templecd_et = (EditText) rootView.findViewById(R.id.btn_insert_ptemplecd);
            programname_et = (EditText) rootView.findViewById(R.id.btn_insert_programname);
            programtype_et = (EditText) rootView.findViewById(R.id.btn_insert_programtype);
            programprice_et = (EditText) rootView.findViewById(R.id.btn_insert_price);
            programdetail_et = (EditText) rootView.findViewById(R.id.btn_insert_detail);
            maxperson_et = (EditText) rootView.findViewById(R.id.btn_insert_maxperson);


            btnsave2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    ModelTemple model = new ModelTemple();
                    model.setTemplecd(templecd_et.getText().toString());
                    model.setProgramname(programname_et.getText().toString());
                    model.setProgramtype(Integer.valueOf(programtype_et.getText().toString()));
                    model.setProgramprice(Integer.valueOf(programprice_et.getText().toString()));
                    model.setProgramdetail(programdetail_et.getText().toString());
                    model.setMaxperson(Integer.valueOf(maxperson_et.getText().toString()));
                    new HttpTempleProgramInsert().execute(model);
                    getActivity().finish();
                }

            });
            return rootView;
        }
        //Insert Thread
        class HttpTempleProgramInsert extends AsyncTask<ModelTemple, Integer, Integer> {

            private ProgressDialog waitDlg = null;
            private boolean calling  = false;


            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                waitDlg = new ProgressDialog(getContext());
                waitDlg.setMessage("불러오는 중");
                waitDlg.show();
            }

            @Override
            protected Integer doInBackground(ModelTemple... params) {

                Integer result = new HttpTemple().templeprogramInsert(params[0]);
                return result;

            }

            @Override
            protected void onPostExecute(Integer result) {
                super.onPostExecute(result);


                if (waitDlg != null) {
                    waitDlg.dismiss();
                    waitDlg = null;
                }

                calling = false;
            }
        }
    }

}
