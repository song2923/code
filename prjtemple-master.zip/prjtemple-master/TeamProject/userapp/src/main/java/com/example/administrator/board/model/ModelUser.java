package com.example.administrator.board.model;


import android.os.Parcel;
import android.os.Parcelable;

public class ModelUser implements Parcelable {
    
    private String userid    ="";
    private String userpassword    ="";
    private String username  ="";
    private String userphone =null;
    private String useremail ="";
    public ModelUser() {
    }
    public ModelUser(String userid, String userpassword, String username,
                     String userphone, String useremail) {
        super();
        this.userid = userid;
        this.userpassword = userpassword;
        this.username = username;
        this.userphone = userphone;
        this.useremail = useremail;
    }
    public String getUserid() {
        return userid;
    }
    public void setUserid(String userid) {
        this.userid = userid;
    }
    public String getuserpassword() {
        return userpassword;
    }
    public void setuserpassword(String userpassword) {
        this.userpassword = userpassword;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getUserphone() {
        return userphone;
    }
    public void setUserphone(String userphone) {
        this.userphone = userphone;
    }
    public String getUseremail() {
        return useremail;
    }
    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(userid);
        dest.writeString(userpassword);
        dest.writeString(username);
        dest.writeString(userphone);
        dest.writeString(useremail);
    }
    public ModelUser(Parcel in) {
        userid = in.readString();
        userpassword = in.readString();
        username = in.readString();
        userphone = in.readString();
        useremail = in.readString();
    }
    public static final Creator<ModelUser> CREATOR = new Creator<ModelUser>() {
        @Override
        public ModelUser createFromParcel(Parcel in) {
            return new ModelUser(in);
        }

        @Override
        public ModelUser[] newArray(int size) {
            return new ModelUser[size];
        }
    };
    @Override
    public String toString() {
        return "ModelUser [userid=" + userid + ", userpassword=" + userpassword
                + ", username=" + username + ", userphone=" + userphone
                + ", useremail=" + useremail + "]";
    }
    public ModelUser(String userid, String userpassword) {
        super();
        this.userid = userid;
        this.userpassword = userpassword;
    }
    @Override
    public int describeContents() {
        return 0;
    }

}
