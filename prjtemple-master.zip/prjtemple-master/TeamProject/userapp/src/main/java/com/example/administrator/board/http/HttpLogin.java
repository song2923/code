package com.example.administrator.board.http;

import com.example.administrator.board.model.ModelUser;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * Created by Administrator on 2017-08-16.
 */

public class HttpLogin {


    public ModelUser loginuser(String userid, String userpassword) {
        String weburl = "http://10.0.2.1:8080/register/loginrest";
        HttpRequest request = null;
        int httpCode = 0;
        JSONObject response = null;
        ModelUser result = null;

        //입력받은 id와 pw를 서버에 입력한다. (---> mapper)
        try {
            request = new HttpRequest(weburl).addHeader("charset", "utf-8");
            request.addParameter("userid", userid);
            request.addParameter("userpassword", userpassword);
            httpCode = request.post();

            if (HttpURLConnection.HTTP_OK == httpCode) {
                //접속에 성공하면 정보를 JSONObject로 받아온다.
                response = request.getJSONObjectResponse();
            }
                //JSONObject(json string) -> ModelUser객체(java object)
                Gson gson = new Gson();
                result = gson.fromJson(String.valueOf(response), ModelUser.class);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //ModelUser result
        return result;
    }

    public String idcheck(String userid) {
        String weburl = "http://10.0.2.1:8080/register/idcheckrest";
        HttpRequest request = null;
        int httpCode = 0;
        String response = "";

        try {
            request = new HttpRequest(weburl).addHeader("charset", "utf-8");
            request.addParameter("userid", userid);
            httpCode = request.post();

            if (HttpURLConnection.HTTP_OK == httpCode) {
                response = request.getStringResponse();

            } else {
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            request.close();
        }

        return response;
    }

    public String insertuser(String userid, String userpassword, String username, String userphone, String useremail) {
        String weburl = "http://10.0.2.1:8080/register/insertuserrest";
        HttpRequest request = null;
        int httpCode = 0;
        String response = "";

        try {
            request = new HttpRequest(weburl).addHeader("charset", "utf-8");
            request.addParameter("userid", userid);
            request.addParameter("userpassword", userpassword);
            request.addParameter("username", username);
            request.addParameter("userphone", userphone);
            request.addParameter("useremail", useremail);
            httpCode = request.post();

            if (HttpURLConnection.HTTP_OK == httpCode) {
                response = request.getStringResponse();

            } else {
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            request.close();
        }

        return response;
    }


    public String edituser(String userid, String userpassword, String username, String userphone, String useremail) {
        String weburl = "http://10.0.2.1:8080/register/edituserrest";

        HttpRequest request = null;
        String response = "";

        int httpCode = 0;

        try {
            request = new HttpRequest(weburl).addHeader("charset", "utf-8");
            request.addParameter("userid", userid);
            request.addParameter("userpassword", userpassword);
            request.addParameter("username", username);
            request.addParameter("userphone", userphone);
            request.addParameter("useremail", useremail);
            httpCode = request.post();

            if (HttpURLConnection.HTTP_OK == httpCode) {
                response = request.getStringResponse();
            } else {
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            request.close();
        }

        return response;
    }

    public String outuser(String userid) {
        String weburl = "http://10.0.2.1:8080/register/outuserrest";

        HttpRequest request = null;
        String response = "";

        int httpCode = 0;

        try {
            request = new HttpRequest(weburl).addHeader("charset", "utf-8");
            request.addParameter("userid", userid);
            httpCode = request.post();

            if (HttpURLConnection.HTTP_OK == httpCode) {
                response = request.getStringResponse();

            } else {
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            request.close();
        }

        return response;

    }



}
