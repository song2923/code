package com.example.administrator.board;

import com.example.administrator.board.http.HttpRequest;
import com.example.administrator.board.model.ModelBoard_Article;
import com.google.gson.Gson;

import org.junit.Test;

import java.io.IOException;
import java.net.HttpURLConnection;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }

    @Test
    public void test_insertboard() {
        String weburl = "http://192.168.0.41:8080/board/insertBoard";

        HttpRequest request = null;
        String response = null;

        int httpCode = 0;

        try {
            ModelBoard_Article obj = new ModelBoard_Article("title", "content");
            String data = new Gson().toJson(obj);

            request = new HttpRequest(weburl).addHeader("charset", "utf-8")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Accept", "application/json");

            httpCode = request.post(data);


            if (HttpURLConnection.HTTP_OK == httpCode) {

                try {
                    response = request.getStringResponse();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
            }


            assertNotNull(response);
            assertEquals("1", response);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            request.close();
        }


    }
}